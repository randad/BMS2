//var name = $("#name").val();
//var email = $("#email").val();
//var password = $("#password").val();
//var cpassword = $("#cpassword").val();
//var name=$("#name").val();
//var userName=$("#userName").val(); 
//var password=$("#password").val();
//var cPassword=$("#cPassword").val();
//var guardianType=$("#guardianType").val();
//var guardianName=$("#guardianName").val();
//var address=$("#address").val();
//var citizenship=$("#citizenship").val();
//var	state=$("#state").val();
//var	country=$("#country").val();
//var email=$("#country").val(); 
//var gender=$("#gender").val();
//var	marital_Status=$("#marital_Status").val();
//var	contact_no=$("#contact_no").val();
//var	doB=$("#doB").val();
//var	registrationDate=$("#registrationDate").val();
//var	account_type=$("#account_type").val();
//var	branch_Name=$("#branch_Name").val();
//var	citizen_status=$("#citizen_status").val();
//var initDepositAmount=$("#initDepositAmount").val();
//var	idProofType=$("#idProofType").val();
//var	idDocNum=$("#idDocNum").val();
//var refName=$("#refName").val();
//var refAccNum=$("#refAccNum").val();
//var refAddress=$("#refAddress").val();


$(document).ready(function() {
	
$("#register").click(function() {

var regex=/^R-[0-9]{3}$/i;
var age=$("#age").val();
var name=$("#name").val();
var userName=$("#userName").val(); 
var password=$("#password").val();
var cPassword=$("#cPassword").val();
var guardianType=$("#guardianType").val();
var guardianName=$("#guardianName").val();
var address=$("#address").val();
var citizenship=$("#citizenship").val();
var	state=$("#state").val();
var	country=$("#country").val();
var email=$("#email").val(); 
var gender=$("#gender").val();
var	marital_Status=$("#marital_Status").val();
var	contact_no=$("#contact_no").val();
var	doB=$("#doB").val();
var	registrationDate=$("#registrationDate").val();
var	account_type=$("#account_type").val();
var	branch_Name=$("#branch_Name").val();
var	citizen_status=$("#citizen_status").val();
var initDepositAmount=$("#initDepositAmount").val();
var	idProofType=$("#idProofType").val();
var	idDocNum=$("#idDocNum").val();
var refName=$("#refName").val();
var refAccNum=$("#refAccNum").val();
var refAddress=$("#refAddress").val();

function getAge(doB) {
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}


if (name == '' || email == '' || password == '' || cpassword == '' || userName == '' ||guardianType == ''|| 
		guardianName==''||address==''||citizenship==''||state==''||country==''||gender==''|| marital_Status==''
		||contact_no==''||doB==''||registrationDate==''||account_type==''||branch_Name==''||citizen_status==''
		||initDepositAmount==''||idProofType==''||idDocNum==''||refAccNum==''||refAddress=='') {
alert("Please fill all fields...!!");
}
//if (name.match("/^R-[0-9]{3}$/i"))
//else if(customerId.match(regex)==null){
//alert("Please enter valid customer id");	
//}
else if(getAge(doB)<18 || getAge(doB)>96){
alert("plese enter valid age(between 18 and 96)");}
else if ((password.length) < 8) {
alert("Password should atleast 8 character in length.");}

else if (!(password).match(cpassword)) {
alert("Your passwords don't match. Try again?");
} else { 
$.post("CustomerRegistation", {
name1: name,
email1: email,
password1: password,
},  function(data) {
 
	document.write("welcome to website");
	document.write("<br><a href=login.jsp>clock</a>");
	  
     
});
}
});
});