import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.login.service.CustomerBO;
import com.cts.model.Customer;


 
public class CustomerRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter pw = response.getWriter();
		 
		Customer  c= new Customer();
		//c.setCustId("custId");
		c.setName(request.getParameter("name"));
		c.setUserName(request.getParameter("userName"));
		c.setPassword(request.getParameter("password"));
		c.setGuardianType(request.getParameter("guardianType"));
		c.setGuardianName(request.getParameter("guardianName"));
		c.setAddress(request.getParameter("address"));
		c.setCitizenShip(request.getParameter("citizenship"));
		c.setState(request.getParameter("state"));
		c.setCountry(request.getParameter("country"));
		c.setEmail(request.getParameter("email"));
		c.setGender(request.getParameter("gender"));
		c.setMartialStatus(request.getParameter("marital_Status"));
		c.setContactNumber(request.getParameter("contact_no"));
		String date=request.getParameter("doB");
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		//String date1=request.getParameter("registrationDate");
		try
		{
		c.setDateofBirth(sdf.parse(date));
		//c.setRegistrationDate(sdf.parse(date1));
		}
		catch(ParseException e)
		{
			System.out.println("edc:"+e);
		}
		
		
		c.setAccounttype(request.getParameter("account_type"));
		c.setBranchName(request.getParameter("branch_Name"));
		c.setCitizenstatus(request.getParameter("citizen_status"));
		c.setInitialDepositAmount(Float.parseFloat(request.getParameter("initDepositAmount")));
		c.setIdentificationProofType(request.getParameter("idProofType"));
		c.setIdentificationocumentNo(request.getParameter("idDocNum"));
		c.setReferenceaccountholdername(request.getParameter("refName"));
		c.setReferenceAccountHolderaccNo(request.getParameter("refAccNum"));
		c.setReferenceAccountHolderAddress(request.getParameter("refAddress"));
		
		boolean rsult= CustomerBO.registerCustomer(c);
		
		
	}	

}
