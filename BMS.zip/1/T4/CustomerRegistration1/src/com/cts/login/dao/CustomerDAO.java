package com.cts.login.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import com.cts.model.Customer;


	public class CustomerDAO {

		
		
		public static boolean registerCustomer(Customer c)
		{
			
			boolean result=false;
			
			 
			
			try
			{
				
				Class.forName("com.mysql.jdbc.Driver");
				String url="jdbc:mysql://10.155.104.28/bmsdb";
				
			Connection con=	  DriverManager .getConnection(url,"root","root");
			String registerSQL= "insert into customer_details (name,user_name,password,guardian_type,"
					+ "guardian_name,address,country_id,email,gender,martial_status,contact_number,date_of_birth,"
					+ "branch_name,citzenship,id_prooftype,id_no,reference_acc_name,reference_acc_no,reference_acc_address,customer_id) "
					+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			
			PreparedStatement pstat=
					con.prepareStatement(registerSQL);
			pstat.setString(1, c.getName());
			pstat.setString(2,c.getUserName());
			pstat.setString(3,c.getPassword());
			pstat.setString(4,c.getGuardianType());
			pstat.setString(5,c.getGuardianName());
			pstat.setString(6,c.getAddress());
			pstat.setString(7,c.getCountry());
			pstat.setString(8,c.getEmail());
			pstat.setString(9,c.getGender());
			pstat.setString(10,c.getMartialStatus());
			pstat.setString(11,c.getContactNumber());
			pstat.setDate(12,new java.sql.Date(c.getDateofBirth().getTime()));
			pstat.setString(13,c.getBranchName());
			pstat.setString(14,c.getCitizenShip());
			pstat.setString(15,c.getIdentificationProofType());
			pstat.setString(16,c.getIdentificationocumentNo());
			pstat.setString(17,c.getReferenceaccountholdername());
			pstat.setString(18,c.getReferenceAccountHolderaccNo());
			pstat.setString(19,c.getReferenceAccountHolderAddress());
			pstat.setString(20, c.getCustId());
			int resultTest=    pstat.executeUpdate(); 
			if(resultTest>=1)
			{
				result=true;
			}
			
		}
		catch(Exception e)
		 {
			System.out.println("exception e"+e);
		}
		System.out.println("in dao id:"+result);
		return result;
		
	}
	
}
			


