package com.cts.login.service;

 
import java.util.ArrayList;
import java.util.List;

import com.cts.login.dao.CustomerDAO;
import com.cts.model.Customer;



 

 
 
public class CustomerBO {
	
	
	public static boolean registerCustomer(Customer cust)
	{
		
		
		String custIdPattern="R-";  
		
		/*//if(customerDAO.generateId()!=null)
		{
			int cid= Integer.parseInt(customerDAO.generateId().substring(2,5));
			
			custIdPattern= custIdPattern+(cid+1);
			cust.seti
		}*/
		
		{
		cust.setCustId("R-100");
		
		boolean result=false;
		
		   result= CustomerDAO.registerCustomer(cust);
		 
		return result;
		
	}
	
	 
}
}
