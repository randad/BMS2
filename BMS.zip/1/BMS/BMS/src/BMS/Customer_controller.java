package BMS;

import java.io.IOException;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Customer_controller")
public class Customer_controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private Customer_DAO cDAO;
 
    public void init() {
        /*String jdbcURL = getServletContext().getInitParameter("jdbcURL");
        String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
        String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
 */
        cDAO= new Customer_DAO();
 
    }
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("s1");
        System.out.println(action);
        try {
            switch (action) {
            case "Sign Up":
                customer_reg(request, response);
                System.out.println("1");
                break;
            case "Login":
                login_cus(request, response);
                System.out.println("2");
                break;
            case "Logout":
               logout_cus(request, response);
               System.out.println("3");
                break;
            case "Apply Personal Loan":
                update_cus_loan(request, response);
                break;
            case "Update":
            	System.out.println("fgsgfjsg");
                update_cus(request, response);
                System.out.println("4");
                break;
            /*case "Loan":
                updateBook(request, response);
                break;
            case "Transactions":
               updateBook(request, response);
                break;
            case "Statements":
                updateBook(request, response);
                break;
            default:
                listBook(request, response);
                break;*/
            }
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }
 
   
 
    private void update_cus_loan(HttpServletRequest request, HttpServletResponse response) throws ParseException, IOException, SQLException {
    	
    	
    	
    	 HttpSession session=request.getSession();
    	
    	 SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
    	 String Loan_type=request.getParameter("loantype");
    	 String Loan_amount=request.getParameter("loanamount");
    	 java.util.Date d1= sdf.parse(request.getParameter("loanapplydate"));
    	 Date Loan_apply_date=new Date(d1.getTime());
    	 java.util.Date d2= sdf.parse(request.getParameter("loanissuedate"));
    	 Date Loan_issue_date=new Date(d2.getTime());
    	 String rate_of_intrest=request.getParameter("rateofinterest");
    	 String duration_of_loan =request.getParameter("duration of the loan");
    	 String annual_income=request.getParameter("annualincome");
    	 String company_name=request.getParameter("companyname");
    	 String designation=request.getParameter("designation");
    	 String total_exp=request.getParameter("totalexp");
    	 String exp_with_current_company=request.getParameter("expwithcurrentcompany");
    	 Personal_Housing_details d=new Personal_Housing_details(Loan_type, Double.parseDouble(Loan_amount), Loan_apply_date,Loan_issue_date,Double.parseDouble(rate_of_intrest),  Integer.parseInt(duration_of_loan),  Double.parseDouble(annual_income),  company_name,  designation,Double.parseDouble(total_exp), Double.parseDouble(exp_with_current_company));
    	 String p=(String) session.getAttribute("c_id");
    	 cDAO.updateedu_loan(p,d);
    	 response.sendRedirect("./customerhome.jsp");
	}

	private void customer_reg(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
    	 SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
    	 String name=request.getParameter("name");
    	 String username=request.getParameter("username");
    	 String password=request.getParameter("password");
    	 String re_type_password=request.getParameter("reenterpassword");
    	 String gaurdian_type=request.getParameter("gaurdiantype");
    	 String gaurdian_name=request.getParameter("gaurdianname");
    	 String address=request.getParameter("address");
    	 String citizenship=request.getParameter("citizenship");
    	 String state=request.getParameter("state");
    	 String country=request.getParameter("country");
    	 String email_address=request.getParameter("email");
    	 String gender=request.getParameter("gender");
    	 String marital_status=request.getParameter("marital status");
    	 String contact_no=request.getParameter("contactno");
    	 java.util.Date d1= sdf.parse(request.getParameter("dob"));
    	 
    	 
    	 Date date_of_birth=new Date(d1.getTime());
    	 java.util.Date d2= sdf.parse(request.getParameter("registrationdate"));
    	 Date registration_date = new Date(d2.getTime());
    	 String account_type=request.getParameter("accounttype");
    	 String branch_name=request.getParameter("branchname");
    	 String citizen_status=request.getParameter("citizenshipstatus");
    	 double initial_deposit_amount=Double.parseDouble(request.getParameter("initialdepositamount"));
    	 String identification_proof_type=request.getParameter("identificationprooftype");
    	 String identification_document_no=request.getParameter("identificationdocumentnumber");
    	 String reference_account_holder_name=request.getParameter("referenceaccountholdername");
    	 String reference_account_holder_account_no=request.getParameter("referenceaccountholderaccountno");
    	 String reference_account_holder_address=request.getParameter("referenceaccountholderaddress");
 
        Customer c = new Customer( name,  username,  password,  re_type_password,  gaurdian_type,
    		      gaurdian_name,  address,  citizenship,  state,  country,
    			 email_address,  gender,  marital_status,  contact_no,  date_of_birth,
    			 registration_date,  account_type,  branch_name,  citizen_status,
    			 initial_deposit_amount,  identification_proof_type,  identification_document_no,
    			 reference_account_holder_name,  reference_account_holder_account_no,
    			 reference_account_holder_address);
       cDAO.insertcustomer(c);
       response.sendRedirect("./home.jsp");
    }
 
    private void login_cus(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
    	 SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    	
    	 String customer_id=request.getParameter("customerid");
    	 HttpSession session=request.getSession();
           session.setAttribute("c_id", customer_id);
         
    	 String password=request.getParameter("password");
    	 if(cDAO.logincustomer(customer_id,password))
    	 {
    		  System.out.println("Preetham");
    		   Customer c1=cDAO.check(customer_id);
    	       long x=cDAO.acc_no(customer_id);
    	       session.setAttribute("c_id",customer_id);
    	       session.setAttribute("acc_no",x);
    	       session.setAttribute("name",c1.getName());
    	       session.setAttribute("country",c1.getCountry());
    	       session.setAttribute("state",c1.getState());
    	       session.setAttribute("gender",c1.getGender());
    	       //System.out.println("//////////////////////////////////");
    	       java.util.Date d1=sdf.parse(c1.getDate_of_birth().toString());
    	       sdf=new SimpleDateFormat("dd/MM/yyyy");
    	       String d2=sdf.format(d1);
    	       session.setAttribute("dob",d2);
             // System.out.println("//////////////////////////////////");
    	       sdf=new SimpleDateFormat("yyyy-MM-dd");
    	       java.util.Date d11=sdf.parse(c1.getRegistration_date().toString());
    	       sdf=new SimpleDateFormat("dd/MM/yyyy");
    	       String d21=sdf.format(d11);
    	       session.setAttribute("r_date",d21);
    	       session.setAttribute("branch",c1.getBranch_name());
    	       session.setAttribute("ifsc","HDVLOO12");
    	       session.setAttribute("id_type",c1.getIdentification_proof_type());
    	       session.setAttribute("id_no",c1.getIdentification_document_no());
    	       session.setAttribute("ref_name",c1.getReference_account_holder_name());
    	       session.setAttribute("ref_no",c1.getReference_account_holder_account_no());
    	       session.setAttribute("ref_add",c1.getReference_account_holder_address());
    	       session.setAttribute("add",c1.getAddress());
    	       session.setAttribute("con_no",c1.getContact_no());
    	       session.setAttribute("email",c1.getEmail_address());
    	       session.setAttribute("m_status",c1.getMarital_status());
    	       session.setAttribute("acc_type",c1.getAccount_type());
    	       session.setAttribute("cit",c1.getCitizenship());
    	       session.setAttribute("cit_status",c1.getCitizen_status());
    	       session.setAttribute("gaur_type",c1.getGaurdian_type());
    	       session.setAttribute("gar_name",c1.getGaurdian_name());
    	       
           response.sendRedirect("./customerhome.jsp");
    	 }
    	 else
    	 {
    		System.out.println("invalid credentials");
    	 response.sendRedirect("./customerlogin.jsp");
    	 }
    }
    private void logout_cus(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
        System.out.println("Sucessfully Logged Out");
    	response.sendRedirect("./home.jsp");
    }
    
    private void update_cus(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ParseException {
    	
    	
        System.out.println("121231");
    	 SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
    	 String name=request.getParameter("name");
    	 HttpSession session=request.getSession();
    	  String cus_id=(String) session.getAttribute("c_id");
    	 String gaurdian_type=request.getParameter("gaurdiantype");
    	 System.out.println("121231");
    	 String gaurdian_name=request.getParameter("gaurdianname");
    	 String address=request.getParameter("address");
    	 String citizenship=request.getParameter("citizenship");
    	 String state=request.getParameter("state");
    	 System.out.println("121231");
    	 String country=request.getParameter("country");
    	 String email_address=request.getParameter("email");
    	 String gender=request.getParameter("gender");
    	 System.out.println("121231");
    	 String marital_status=request.getParameter("marital status");
    	 String contact_no=request.getParameter("contactno");
    	 java.util.Date d1= sdf.parse(request.getParameter("dob"));
    	 Date d11=new java.sql.Date(d1.getTime());
    	 System.out.println("121231");
    	 System.out.println("------------------");
    	 String account_type=request.getParameter("accounttype"); System.out.println("121");
    	 String branch_name=request.getParameter("branchname");
    	 System.out.println("121231");
    	 String citizen_status=request.getParameter("citizenshipstatus");
    	 
    	 String identification_proof_type=request.getParameter("identificationprooftype");
    	 String identification_document_no=request.getParameter("identificationdocumentnumber");
    	 String reference_account_holder_name=request.getParameter("referenceaccountholdername");
    	 String reference_account_holder_account_no=request.getParameter("referenceaccountholderaccountno");
    	 String reference_account_holder_address=request.getParameter("referenceaccountholderaddress");
         String ifsc=request.getParameter("ifsccode");
        Customer c = new Customer( name,  gaurdian_type,
    		      gaurdian_name,  address,  citizenship,  state,  country,
    			 email_address,  gender,  marital_status,  contact_no,  d11,
    			  account_type,  branch_name,  citizen_status,
    			  identification_proof_type,  identification_document_no,
    			 reference_account_holder_name,  reference_account_holder_account_no,
    			 reference_account_holder_address);
      System.out.println("fbhbjskbhfgildsiluafg");
       cDAO.updatecustomer(cus_id,c,ifsc);
       
       response.sendRedirect("./customerhome.jsp");
    }
}
