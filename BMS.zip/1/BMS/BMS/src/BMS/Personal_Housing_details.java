package BMS;

import java.sql.Date;

public class Personal_Housing_details {
	protected String Loan_type;
	protected double Loan_amount;
	protected Date Loan_apply_date;
	protected Date Loan_issue_date;
	protected double rate_of_intrest;
	protected int duration_of_loan;
	protected double annual_income;
	protected String company_name;
	protected String designation;
	protected double total_exp;
	protected double exp_with_current_company;
	public String getLoan_type() {
		return Loan_type;
	}

	public void setLoan_type(String loan_type) {
		Loan_type = loan_type;
	}

	public double getLoan_amount() {
		return Loan_amount;
	}

	public void setLoan_amount(double loan_amount) {
		Loan_amount = loan_amount;
	}

	public Date getLoan_apply_date() {
		return Loan_apply_date;
	}

	public void setLoan_apply_date(Date loan_apply_date) {
		Loan_apply_date = loan_apply_date;
	}

	public Date getLoan_issue_date() {
		return Loan_issue_date;
	}

	public void setLoan_issue_date(Date loan_issue_date) {
		Loan_issue_date = loan_issue_date;
	}

	public double getRate_of_intrest() {
		return rate_of_intrest;
	}

	public void setRate_of_intrest(double rate_of_intrest) {
		this.rate_of_intrest = rate_of_intrest;
	}

	public int getDuration_of_loan() {
		return duration_of_loan;
	}

	public void setDuration_of_loan(int duration_of_loan) {
		this.duration_of_loan = duration_of_loan;
	}

	public Personal_Housing_details(String loan_type, double loan_amount, Date loan_apply_date, Date loan_issue_date,
			double rate_of_intrest, int duration_of_loan, double annual_income, String company_name, String designation,
			double total_exp, double exp_with_current_company) {
		super();
		Loan_type = loan_type;
		Loan_amount = loan_amount;
		Loan_apply_date = loan_apply_date;
		Loan_issue_date = loan_issue_date;
		this.rate_of_intrest = rate_of_intrest;
		this.duration_of_loan = duration_of_loan;
		this.annual_income = annual_income;
		this.company_name = company_name;
		this.designation = designation;
		this.total_exp = total_exp;
		this.exp_with_current_company = exp_with_current_company;
	}
	
	public double getAnnual_income() {
		return annual_income;
	}
	public void setAnnual_income(double annual_income) {
		this.annual_income = annual_income;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getTotal_exp() {
		return total_exp;
	}
	public void setTotal_exp(double total_exp) {
		this.total_exp = total_exp;
	}
	public double getExp_with_current_company() {
		return exp_with_current_company;
	}
	public void setExp_with_current_company(double exp_with_current_company) {
		this.exp_with_current_company = exp_with_current_company;
	}
	public Personal_Housing_details(double annual_income, String company_name, String designation, double total_exp,
			double exp_with_current_company) {
		super();
		this.annual_income = annual_income;
		this.company_name = company_name;
		this.designation = designation;
		this.total_exp = total_exp;
		this.exp_with_current_company = exp_with_current_company;
	}
	public Personal_Housing_details() {
		super();
	}
	
	
}
