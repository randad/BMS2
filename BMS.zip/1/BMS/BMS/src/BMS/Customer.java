package BMS;

import java.sql.Date;

public class Customer {
	protected String customer_id;
	protected long account_number;

	protected String name;
	protected String username;
	protected String password;
	protected String re_type_password;
	protected String gaurdian_type;
	protected String gaurdian_name;
	protected String address;
	protected String citizenship;
	protected String state;
	protected String country;
	protected String email_address;
	protected String gender;
	protected String marital_status;
	protected String contact_no;
	protected Date date_of_birth;
	protected Date registration_date;
	protected String account_type;
	protected String branch_name;
	protected String citizen_status;
	protected double initial_deposit_amount;
	protected String identification_proof_type;
	protected String identification_document_no;
	protected String reference_account_holder_name;
	protected String reference_account_holder_account_no;
	protected String reference_account_holder_address;
	public Customer() {
		super();
	}
	public Customer(String name, String username, String password, String re_type_password, String gaurdian_type,
			String gaurdian_name, String address, String citizenship, String state, String country,
			String email_address, String gender, String marital_status, String contact_no, Date date_of_birth,
			Date registration_date, String account_type, String branch_name, String citizen_status,
			double initial_deposit_amount, String identification_proof_type, String identification_document_no,
			String reference_account_holder_name, String reference_account_holder_account_no,
			String reference_account_holder_address) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.re_type_password = re_type_password;
		this.gaurdian_type = gaurdian_type;
		this.gaurdian_name = gaurdian_name;
		this.address = address;
		this.citizenship = citizenship;
		this.state = state;
		this.country = country;
		this.email_address = email_address;
		this.gender = gender;
		this.marital_status = marital_status;
		this.contact_no = contact_no;
		this.date_of_birth = date_of_birth;
		this.registration_date = registration_date;
		this.account_type = account_type;
		this.branch_name = branch_name;
		this.citizen_status = citizen_status;
		this.initial_deposit_amount = initial_deposit_amount;
		this.identification_proof_type = identification_proof_type;
		this.identification_document_no = identification_document_no;
		this.reference_account_holder_name = reference_account_holder_name;
		this.reference_account_holder_account_no = reference_account_holder_account_no;
		this.reference_account_holder_address = reference_account_holder_address;
	}
	public Customer(String name, String gaurdian_type, String gaurdian_name, String address, String citizenship,
			String state, String country, String email_address, String gender, String marital_status,
			String contact_no, Date date_of_birth,  String account_type, String branch_name,
			String citizen_status, String identification_proof_type, String identification_document_no,
			String reference_account_holder_name, String reference_account_holder_account_no,
			String reference_account_holder_address) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.gaurdian_type = gaurdian_type;
		this.gaurdian_name = gaurdian_name;
		this.address = address;
		this.citizenship = citizenship;
		this.state = state;
		this.country = country;
		this.email_address = email_address;
		this.gender = gender;
		this.marital_status = marital_status;
		this.contact_no = contact_no;
		this.date_of_birth = date_of_birth;
		
		this.account_type = account_type;
		this.branch_name = branch_name;
		this.citizen_status = citizen_status;
		this.identification_proof_type = identification_proof_type;
		this.identification_document_no = identification_document_no;
		this.reference_account_holder_name = reference_account_holder_name;
		this.reference_account_holder_account_no = reference_account_holder_account_no;
		this.reference_account_holder_address = reference_account_holder_address;
	
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public long getAccount_number() {
		return account_number;
	}
	public void setAccount_number(long account_number) {
		this.account_number = account_number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRe_type_password() {
		return re_type_password;
	}
	public void setRe_type_password(String re_type_password) {
		this.re_type_password = re_type_password;
	}
	public String getGaurdian_type() {
		return gaurdian_type;
	}
	public void setGaurdian_type(String gaurdian_type) {
		this.gaurdian_type = gaurdian_type;
	}
	public String getGaurdian_name() {
		return gaurdian_name;
	}
	public void setGaurdian_name(String gaurdian_name) {
		this.gaurdian_name = gaurdian_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCitizenship() {
		return citizenship;
	}
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	public String getContact_no() {
		return contact_no;
	}
	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public Date getRegistration_date() {
		return registration_date;
	}
	public void setRegistration_date(Date registration_date) {
		this.registration_date = registration_date;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public String getCitizen_status() {
		return citizen_status;
	}
	public void setCitizen_status(String citizen_status) {
		this.citizen_status = citizen_status;
	}
	public double getInitial_deposit_amount() {
		return initial_deposit_amount;
	}
	public void setInitial_deposit_amount(double initial_deposit_amount) {
		this.initial_deposit_amount = initial_deposit_amount;
	}
	public String getIdentification_proof_type() {
		return identification_proof_type;
	}
	public void setIdentification_proof_type(String identification_proof_type) {
		this.identification_proof_type = identification_proof_type;
	}
	public String getIdentification_document_no() {
		return identification_document_no;
	}
	public void setIdentification_document_no(String identification_document_no) {
		this.identification_document_no = identification_document_no;
	}
	public String getReference_account_holder_name() {
		return reference_account_holder_name;
	}
	public void setReference_account_holder_name(String reference_account_holder_name) {
		this.reference_account_holder_name = reference_account_holder_name;
	}
	public String getReference_account_holder_account_no() {
		return reference_account_holder_account_no;
	}
	public void setReference_account_holder_account_no(String reference_account_holder_account_no) {
		this.reference_account_holder_account_no = reference_account_holder_account_no;
	}
	public String getReference_account_holder_address() {
		return reference_account_holder_address;
	}
	public void setReference_account_holder_address(String reference_account_holder_address) {
		this.reference_account_holder_address = reference_account_holder_address;
	}
	
}
