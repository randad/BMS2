package BMS;

public class Educational_details {
	protected double course_fee;
	protected String course;
	protected String father_name;
	protected String father_occupation;
	protected double fathers_total_exp;
	protected double fathers_exp_with_current_company;
	protected String ration_card_no;
	protected double annual_income;
	public double getCourse_fee() {
		return course_fee;
	}
	public void setCourse_fee(double course_fee) {
		this.course_fee = course_fee;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getFather_occupation() {
		return father_occupation;
	}
	public void setFather_occupation(String father_occupation) {
		this.father_occupation = father_occupation;
	}
	public double getFathers_total_exp() {
		return fathers_total_exp;
	}
	public void setFathers_total_exp(double fathers_total_exp) {
		this.fathers_total_exp = fathers_total_exp;
	}
	public double getFathers_exp_with_current_company() {
		return fathers_exp_with_current_company;
	}
	public void setFathers_exp_with_current_company(double fathers_exp_with_current_company) {
		this.fathers_exp_with_current_company = fathers_exp_with_current_company;
	}
	public String getRation_card_no() {
		return ration_card_no;
	}
	public void setRation_card_no(String ration_card_no) {
		this.ration_card_no = ration_card_no;
	}
	public double getAnnual_income() {
		return annual_income;
	}
	public void setAnnual_income(double annual_income) {
		this.annual_income = annual_income;
	}
	public Educational_details(double course_fee, String course, String father_name, String father_occupation,
			double fathers_total_exp, double fathers_exp_with_current_company, String ration_card_no,
			double annual_income) {
		super();
		this.course_fee = course_fee;
		this.course = course;
		this.father_name = father_name;
		this.father_occupation = father_occupation;
		this.fathers_total_exp = fathers_total_exp;
		this.fathers_exp_with_current_company = fathers_exp_with_current_company;
		this.ration_card_no = ration_card_no;
		this.annual_income = annual_income;
	}
	public Educational_details() {
		super();
	}
	
	
}
