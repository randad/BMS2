package BMS;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Set;

public class Admin_DAO {

	  private Connection jdbcConnection;
		 
	    public Admin_DAO()
	    {
	    	super();
	    }
	    protected void connect() throws SQLException {
	        if (jdbcConnection == null || jdbcConnection.isClosed()) {
	            try {
	                Class.forName("com.mysql.jdbc.Driver");
	            } catch (ClassNotFoundException e) {
	                throw new SQLException(e);
	            }
	            jdbcConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking","root","root");
	            System.out.println("Succesfull connection");
	        }
	    }
	     
	    protected void disconnect() throws SQLException {
	        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
	            jdbcConnection.close();
	        }
	    }
	     
	    
	     
	   
	    public boolean loginAdmin(String admin_id,String password) throws SQLException{
	    	boolean b=false;
	    	
	        if(admin_id.equals("admin")&&password.equals("Admin123"))
	        {
	        	b=true;
	        }
	     
		    return b;
	    }

	   public boolean updatecustomer(String cusid,Customer c,String ifsc) throws SQLException {
	    System.out.println("fhdafkjdn65432135453651------------");
	    System.out.println(cusid);
	        String sql = "UPDATE customer_details SET c_name=?,country=?,state=?,gender=?,date_of_birth=?,branch_name=?,identification_proof_type=?,identification_document_no=?,reference_account_holder_name=?,reference_account_holder_acc_no=?,reference_account_holder_address=?,address=?,contact_no=?,email_address=?,marital_status=?,account_type=?,citizenship=?,citizen_status=?,gaurdian_type=?,gaurdian_name=? where customer_id=?";
	         
	        connect();
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setString(1, c.getName());
	        statement.setString(2, c.getCountry());
	        statement.setString(3, c.getState());
	        statement.setString(4, c.getGender());
	        statement.setDate(5, c.getDate_of_birth());
	        statement.setString(6, c.getBranch_name());
	        statement.setString(7, c.getIdentification_proof_type());
	        statement.setString(8, c.getIdentification_document_no());
	        statement.setString(9, c.getReference_account_holder_name());
	        statement.setString(10, c.getReference_account_holder_account_no());
	        statement.setString(11, c.getReference_account_holder_address());
	        statement.setString(12, c.getAddress());
	        statement.setLong(13,Long.parseLong(c.getContact_no()));
	        statement.setString(14, c.getEmail_address());
	        statement.setString(15, c.getMarital_status());
	        statement.setString(16, c.getAccount_type());
	        statement.setString(17, c.getCitizenship());
		    statement.setString(18, c.getCitizen_status());
	        statement.setString(19, c.getGaurdian_type());
	        statement.setString(20, c.getGaurdian_name());
	        statement.setString(21, cusid);
	        int rs=statement.executeUpdate();
	        boolean rowInserted = statement.executeUpdate() > 0;
	        System.out.println("Succesfull updation");
	        statement.close();
	        disconnect();
	        return rowInserted;
	    }
	     
	   public Customer check(String c) throws SQLException
	   {
		   String sql="select * from customer_details where customer_id =?";
		   connect();
		   Customer c1=null;
	       PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	       statement.setString(1, c);
	       ResultSet rs=statement.executeQuery();
	       while(rs.next())
	       {
		  c1=new Customer(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14),rs.getDate(15),rs.getDate(16),rs.getString(17),rs.getString(18),rs.getString(19),rs.getDouble(20),rs.getString(21),rs.getString(22),rs.getString(23),rs.getString(24),rs.getString(25));
	       }
		   statement.close();
	       disconnect();
		   return c1;
	   }
	   public long acc_no(String c_id) throws SQLException
	   {
		   String sql="select account_number from customer_details where customer_id =?";
		   connect();
		   long s=0;
	       PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	       statement.setString(1, c_id);
	       ResultSet rs=statement.executeQuery();
	       while(rs.next())
	       {
	       s= rs.getLong(1);
	       }
	       return s;
	   }
	
}
