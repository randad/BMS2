package BMS;


import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


public class Customer_DAO {

	
	    private Connection jdbcConnection;
	 
	    public Customer_DAO()
	    {
	    	super();
	    }
	    protected void connect() throws SQLException {
	        if (jdbcConnection == null || jdbcConnection.isClosed()) {
	            try {
	                Class.forName("com.mysql.jdbc.Driver");
	            } catch (ClassNotFoundException e) {
	                throw new SQLException(e);
	            }
	            jdbcConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/banking","root","root");
	            System.out.println("Succesfull connection");
	        }
	    }
	     
	    protected void disconnect() throws SQLException {
	        if (jdbcConnection != null && !jdbcConnection.isClosed()) {
	            jdbcConnection.close();
	        }
	    }
	     
	    public boolean insertcustomer(Customer c) throws SQLException {
	        String sql = "INSERT INTO customer_details(c_name,username,c_password,re_type_password,gaurdian_type,gaurdian_name,address, citizenship,  state,  country,email_address,gender, marital_status, contact_no,  date_of_birth,registration_date, account_type, branch_name, citizen_status,initial_deposit_amount, identification_proof_type, identification_document_no,reference_account_holder_name,reference_account_holder_acc_no,reference_account_holder_address,customer_id,account_number) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	        String sql1="select customer_id from customer_details";
	        connect();
	        String f;
	        Statement s=jdbcConnection.createStatement();
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setString(1, c.getName());
	        statement.setString(2, c.getUsername());
	        statement.setString(3, c.getPassword());
	        statement.setString(4, c.getRe_type_password());
	        statement.setString(5, c.getGaurdian_type());
	        statement.setString(6, c.getGaurdian_name());
	        statement.setString(7, c.getAddress());
	        statement.setString(8, c.getCitizenship());
	        statement.setString(9, c.getState());
	        statement.setString(10, c.getCountry());
	        statement.setString(11, c.getEmail_address());
	        statement.setString(12, c.getGender());
	        statement.setString(13, c.getMarital_status());
	        statement.setLong(14, Long.parseLong(c.getContact_no()));
	        statement.setDate(15, c.getDate_of_birth());
	        statement.setDate(16, c.getRegistration_date());
	        statement.setString(17, c.getAccount_type());
	        statement.setString(18, c.getBranch_name());
	        statement.setString(19, c.getCitizen_status());
	        statement.setDouble(20, c.getInitial_deposit_amount());
	        statement.setString(21, c.getIdentification_proof_type());
	        statement.setString(22, c.getIdentification_document_no());
	        statement.setString(23, c.getReference_account_holder_name());
	        statement.setString(24, c.getReference_account_holder_account_no());
	        statement.setString(25, c.getReference_account_holder_address());
	        Set<String> u=new HashSet<String>();
	        ResultSet rs=s.executeQuery(sql1);
	        while(rs.next())
	        {
	        	u.add(rs.getString(1));
	        }
	      
	        f=CustomerBO.id_generation(u);
	        statement.setString(26,f);
	        Set<Long> u1=new HashSet<Long>();
	        ResultSet rs1=s.executeQuery("select account_number from customer_details");
	        while(rs1.next())
	        {
	        	u1.add(rs1.getLong(1));
	        }
	        long k=CustomerBO.acc_no_generation(u1);
	        statement.setLong(27,k);
	        boolean rowInserted = statement.executeUpdate() > 0;
	        System.out.println("Succesfull insertion");
	        statement.close();
	        disconnect();
	        return rowInserted;
	    }
	     
	   
	    public boolean logincustomer(String customer_id,String password) throws SQLException{
	    	String sql="select customer_id from customer_details where c_password=?";
	    	boolean b=false;
	    	connect();
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setString(1,password);
	        ResultSet resultSet = statement.executeQuery();
	        while(resultSet.next())
	        {
	        	 if(resultSet.getString(1).equals(customer_id))
	        	 {
	        		 b=true;
	        		 System.out.println("Succesfull Login");
	        		 break;
	        	 }
	        }
	        statement.close();
		    disconnect();
		    return b;
	    }

	   public boolean updatecustomer(String cusid,Customer c,String ifsc) throws SQLException {
	    System.out.println("fhdafkjdn65432135453651------------");
	    System.out.println(cusid);
	        String sql = "UPDATE customer_details SET c_name=?,country=?,state=?,gender=?,date_of_birth=?,branch_name=?,identification_proof_type=?,identification_document_no=?,reference_account_holder_name=?,reference_account_holder_acc_no=?,reference_account_holder_address=?,address=?,contact_no=?,email_address=?,marital_status=?,account_type=?,citizenship=?,citizen_status=?,gaurdian_type=?,gaurdian_name=? where customer_id=?";
	         
	        connect();
	        PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	        statement.setString(1, c.getName());
	        statement.setString(2, c.getCountry());
	        statement.setString(3, c.getState());
	        statement.setString(4, c.getGender());
	        statement.setDate(5, c.getDate_of_birth());
	        statement.setString(6, c.getBranch_name());
	        statement.setString(7, c.getIdentification_proof_type());
	        statement.setString(8, c.getIdentification_document_no());
	        statement.setString(9, c.getReference_account_holder_name());
	        statement.setString(10, c.getReference_account_holder_account_no());
	        statement.setString(11, c.getReference_account_holder_address());
	        statement.setString(12, c.getAddress());
	        statement.setLong(13,Long.parseLong(c.getContact_no()));
	        statement.setString(14, c.getEmail_address());
	        statement.setString(15, c.getMarital_status());
	        statement.setString(16, c.getAccount_type());
	        statement.setString(17, c.getCitizenship());
		    statement.setString(18, c.getCitizen_status());
	        statement.setString(19, c.getGaurdian_type());
	        statement.setString(20, c.getGaurdian_name());
	        statement.setString(21, cusid);
	        int rs=statement.executeUpdate();
	        boolean rowInserted = statement.executeUpdate() > 0;
	        System.out.println("Succesfull updation");
	        statement.close();
	        disconnect();
	        return rowInserted;
	    }
	     
	   public Customer check(String c) throws SQLException
	   {
		   String sql="select * from customer_details where customer_id =?";
		   connect();
		   Customer c1=null;
	       PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	       statement.setString(1, c);
	       ResultSet rs=statement.executeQuery();
	       while(rs.next())
	       {
		  c1=new Customer(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12),rs.getString(13),rs.getString(14),rs.getDate(15),rs.getDate(16),rs.getString(17),rs.getString(18),rs.getString(19),rs.getDouble(20),rs.getString(21),rs.getString(22),rs.getString(23),rs.getString(24),rs.getString(25));
	       }
		   statement.close();
	       disconnect();
		   return c1;
	   }
	   public long acc_no(String c_id) throws SQLException
	   {
		   String sql="select account_number from customer_details where customer_id =?";
		   connect();
		   long s=0;
	       PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	       statement.setString(1, c_id);
	       ResultSet rs=statement.executeQuery();
	       while(rs.next())
	       {
	       s= rs.getLong(1);
	       }
	       return s;
	   }
	   public int loan_id(String c_id) throws SQLException
	   {
		   String sql="select laon_id from loan_details where customer_id =?";
		   connect();
		   int s=0;
	       PreparedStatement statement = jdbcConnection.prepareStatement(sql);
	       statement.setString(1, c_id);
	       ResultSet rs=statement.executeQuery();
	       while(rs.next())
	       {
	       s= rs.getInt(1);
	       }
	       return s;
	   }
	   public boolean updateedu_loan(String c_id, Personal_Housing_details p) throws SQLException
	   {
		   boolean b=true;
		   connect();
		   Statement s=jdbcConnection.createStatement();
		   String sql="insert into loan_details(loan_type,loan_amount,loan_apply_date,loan_issue_date,rate_of_intrest,duration_of_the_loan,customer_id,laon_id)values(?,?,?,?,?,?,?,?)";
		   String sql1="insert into personal_housing_loan_details(annual_income,company_name,designation,total_exp,exp_with_current_company,customer_id)values(?,?,?,?,?,?,?)";
		   //String sql2="insert into educational_loan_details(course_fee,course,father_name,father_occupation,father's_total_exp,father's_exp_with_current_company,ration_card_no,annual_income,customer_id)values(?,?,?,?,?,?,?,?,?)";
		   PreparedStatement statement = jdbcConnection.prepareStatement(sql);
		   statement.setString(1,p.getLoan_type());
		   statement.setLong(2,(long) p.getLoan_amount());
		   statement.setDate(3,p.getLoan_apply_date());
		   statement.setDate(4,p.getLoan_issue_date());
		   statement.setLong(5,(long) p.getRate_of_intrest());
		   statement.setLong(6,p.getDuration_of_loan());
		   statement.setString(7,c_id);
		   Set<Integer> u1=new HashSet<Integer>();
	        ResultSet rs1=s.executeQuery("select laon_id from loan_details");
	        while(rs1.next())
	        {
	        	u1.add(rs1.getInt(1));
	        }
	        int k=CustomerBO.loan_id_generation(u1);
		   statement.setInt(8,k);
		   return b;
	   }
	
}
