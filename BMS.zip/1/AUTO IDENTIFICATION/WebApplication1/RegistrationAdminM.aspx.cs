﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        DataLayer d = new DataLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            string s1 = logina.Text;
            d.ForloginA(ref s1);
            logina.Text = s1;
            string passw = passa.Text;
            passa.Attributes.Add("value", passw);
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
            try
            {


                if (Femalea.Checked)
                {
                    d.AdminRegistration(passa.Text, firstnamea.Text, lastnamea.Text, int.Parse(agea.Text), "Female", long.Parse(contacta.Text), emaila.Text, addressa.Text, placea.Text, long.Parse(zipcodea.Text), citya.Text);
                }
                else
                    d.AdminRegistration(passa.Text, firstnamea.Text, lastnamea.Text, int.Parse(agea.Text), "Male", long.Parse(contacta.Text), emaila.Text, addressa.Text, placea.Text, long.Parse(zipcodea.Text), citya.Text);




                HtmlMeta HM = new HtmlMeta();
                HM.HttpEquiv = "refresh";
                HM.Content = "2;url=AutoIdentificationProcess.aspx";

                Response.Write("<script>alert('Registered successfully ')</script>");
                this.Page.Controls.Add(HM);

            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {

            }
        }

        protected void placea_TextChanged(object sender, EventArgs e)
        {
            string s = zipcodea.Text, s2 = citya.Text;
            d.ForPlaceA(placea.Text,ref s,ref s2);
            zipcodea.Text = s;
            citya.Text = s2;
        }

        protected void passa_TextChanged(object sender, EventArgs e)
        {

        }

        protected void firstnamea_TextChanged(object sender, EventArgs e)
        {

        }

        protected void lastnamea_TextChanged(object sender, EventArgs e)
        {

        }

        protected void agea_TextChanged(object sender, EventArgs e)
        {

        }

        protected void contacta_TextChanged(object sender, EventArgs e)
        {

        }

        protected void emaila_TextChanged(object sender, EventArgs e)
        {

        }

        protected void addressa_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            logina.Text = " ";
            passa.Text = " ";
            firstnamea.Text = " ";
            lastnamea.Text = " ";
            agea.Text = " ";
            contacta.Text = " ";
            emaila.Text = " ";
            addressa.Text = " ";
            placea.Text = " ";
            zipcodea.Text = " ";
            citya.Text = " ";
        }
    }
}