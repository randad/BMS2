﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm3 : System.Web.UI.Page
    {
       
        
        protected void Page_Load(object sender, EventArgs e)
        {

            SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\Projects;Initial Catalog=Credentials;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False");
            conn.Open();
            string select = "select count(*) from UserData where LoginId =" + int.Parse(login1.Text);

            SqlCommand cmd = new SqlCommand(select, conn);
            int num = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (num > 0)
            {
                string pass = "select Password from UserData where LoginId =" + int.Parse(login1.Text);
               
                SqlDataAdapter ad = new SqlDataAdapter(pass, conn);
                DataSet paw = new DataSet();
                ad.Fill(paw);
             
                int flag = 0;
                foreach (DataRow item in paw.Tables[0].Rows)
                {
                    if (item[0].ToString() == pass1.Text.ToString())
                    {
                        Response.Write(" successful");
                        flag = 1;
                        HttpCookie ck = new HttpCookie("login");
                        ck.Value = login1.Text;
                        ck.Expires = DateTime.Now.AddMinutes(1);
                        Response.Cookies.Add(ck);
                        Response.Redirect("userdatatable.aspx");
                    }

                }
                if (flag == 0)
                    Response.Write(" unsuccessfull");
            }
            else
            {
                Response.Write(" unsuccessfull");
            }
            conn.Close();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataLayer d4 = new DataLayer();
            if (d4.LoginU(login1.Text,pass1.Text) == 1)
            {
                Response.Write("successful");
                Session["userlogin"] = "yes";
                Response.Redirect("UserDataTableM.aspx");
                
            }

            else
            {
                Response.Write(" unsuccessfull");
            }

        }
    }
}