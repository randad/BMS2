﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace WebApplication1
{
    public partial class WebForm2 : System.Web.UI.Page
    {

        DataLayer d5 = new DataLayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            string d1 = login.Text;
            d5.ForloginU(ref d1);
            login.Text = d1;
            string passw = pass.Text;
            pass.Attributes.Add("value", passw);
        }

        protected void place_TextChanged(object sender, EventArgs e)
        {
            string d = zipcode.Text, d2 = city.Text;
            d5.ForPlaceU(place.Text, ref d, ref d2);
            zipcode.Text = d;
            city.Text = d2;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataLayer d = new DataLayer();
             try
            {
                
                
                if (Female.Checked)
                {
                    d.UserRegistration(pass.Text, firstname.Text, lastname.Text, int.Parse(age.Text),"Female", long.Parse(contact.Text), email.Text,address.Text,place.Text, long.Parse(zipcode.Text), city.Text);
                }
                else
                    d.UserRegistration(pass.Text, firstname.Text, lastname.Text, int.Parse(age.Text), "Male", long.Parse(contact.Text), email.Text, address.Text, place.Text, long.Parse(zipcode.Text), city.Text);
               
                
                

                HtmlMeta HM = new HtmlMeta();
                HM.HttpEquiv = "refresh";
                HM.Content = "2;url=AutoIdentificationProcess.aspx";

               Response.Write("<script>alert('Registered successfully ')</script>");
                this.Page.Controls.Add(HM);

            }

            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            login.Text =" ";
            pass.Text = " ";
            firstname.Text = " ";
            lastname.Text = " ";
            age.Text = " ";
            contact.Text = " ";
            email.Text = " ";
            address.Text = " ";
            place.Text = " ";
            zipcode.Text = " ";
            city.Text = " ";
        }
    }
}