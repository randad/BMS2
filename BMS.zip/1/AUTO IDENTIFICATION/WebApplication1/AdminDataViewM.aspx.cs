﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Convert.ToString(Session["loginadmin"])!= "yes1") 
            {
                Response.Redirect("AdminLoginM.aspx");
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["loginadmin"]= "no1";
            Response.Redirect("AdminDataViewM.aspx");
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
               
            }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("complete.aspx");
        }
          
        }
    }
