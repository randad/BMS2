﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.Configuration;
namespace WebApplication1
{
    public class DataLayer
    {
        SqlConnection con;
        public DataLayer()
        {
            string str = WebConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            con = new SqlConnection(str);
            con.Open();     
        }

        public void UserRegistration(string p, string fn, string ln, int a,string gen, long cn, string em, string addr,string pl, long zip, string city)
        {
          
               
                //SqlDataAdapter sd = new SqlDataAdapter();
                string insert = "insert into UserData(Password,FirstName,LastName,Age,Gender,ContactNumber,Email,Address,ZipCode,City) values(@pass,@fname,@lname,@age,@gender,@cnumber,@email,@address,@zipcode,@city)";
                SqlCommand cmd = new SqlCommand(insert, con);
                // cmd.Parameters.AddWithValue("@login", login.Text);
                cmd.Parameters.AddWithValue("@pass", p);
                cmd.Parameters.AddWithValue("@fname", fn);
                cmd.Parameters.AddWithValue("@lname", ln);
                cmd.Parameters.AddWithValue("@age", a);
                
                 cmd.Parameters.AddWithValue("@gender", gen);
              


                cmd.Parameters.AddWithValue("@cnumber", cn);
                cmd.Parameters.AddWithValue("@email", em);
                cmd.Parameters.AddWithValue("@address", addr + pl);

                cmd.Parameters.AddWithValue("@zipcode", zip);
                cmd.Parameters.AddWithValue("@city", city);
                //cmd.Parameters.AddWithValue("@uid", obj.ToString());
                cmd.ExecuteNonQuery();          
        }

        public void AdminRegistration(string p, string fn, string ln, int a, string gen, long cn, string em, string addr, string pl, long zip, string city)
        {


            //SqlDataAdapter sd = new SqlDataAdapter();
            string insert = "insert into AdminData(Password,FirstName,LastName,Age,Gender,ContactNumber,Email,Address,ZipCode,City) values(@pass,@fname,@lname,@age,@gender,@cnumber,@email,@address,@zipcode,@city)";
            SqlCommand cmd = new SqlCommand(insert, con);
            // cmd.Parameters.AddWithValue("@login", login.Text);
            cmd.Parameters.AddWithValue("@pass", p);
            cmd.Parameters.AddWithValue("@fname", fn);
            cmd.Parameters.AddWithValue("@lname", ln);
            cmd.Parameters.AddWithValue("@age", a);

            cmd.Parameters.AddWithValue("@gender", gen);



            cmd.Parameters.AddWithValue("@cnumber", cn);
            cmd.Parameters.AddWithValue("@email", em);
            cmd.Parameters.AddWithValue("@address", addr + pl);

            cmd.Parameters.AddWithValue("@zipcode", zip);
            cmd.Parameters.AddWithValue("@city", city);
            //cmd.Parameters.AddWithValue("@uid", obj.ToString());
            cmd.ExecuteNonQuery();
        }

        public void ForloginA(ref string log)
        {
            string id = "select top 1 LoginId from AdminData order by LoginId desc";
            SqlDataAdapter sd = new SqlDataAdapter(id, con);
            DataTable dt = new DataTable();
            DataRow dr;
            sd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dr = dt.Rows[0];
                string temp = Convert.ToString(dr[0]);
                int a = int.Parse(temp) + 1;
                log = Convert.ToString(a);
            }
            else
            {
                int b = 200000;
                string s = Convert.ToString(b);
                log = s;

            }
        }

        public void ForPlaceA(string pl,ref string zipc,ref string city)
        {
            string pla = "select zipcode,city from Place where place like '" + pl + "'";
            SqlDataAdapter sd1 = new SqlDataAdapter(pla, con);
            DataTable dt1 = new DataTable();
            DataRow dr1;
            sd1.Fill(dt1);
            dr1 = dt1.Rows[0];
            zipc = Convert.ToString(dr1[0]);
            city = Convert.ToString(dr1[1]);
           
        }

        public void ForloginU(ref string log)
        {
            string id = "select top 1 LoginId from UserData order by LoginId desc";
            SqlDataAdapter sd = new SqlDataAdapter(id, con);
            DataTable dt = new DataTable();
            DataRow dr;
            sd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                dr = dt.Rows[0];
                string temp = Convert.ToString(dr[0]);
                int a = int.Parse(temp) + 1;
                log = Convert.ToString(a);
            }
            else
            {
                int b = 1000;
                string s = Convert.ToString(b);
                log = s;

            }
        }

        public void ForPlaceU(string pl,ref string zipc,ref string city)
        {
            string pla = "select zipcode,city from Place where place like '" + pl + "'";
            SqlDataAdapter sd1 = new SqlDataAdapter(pla, con);
            DataTable dt1 = new DataTable();
            DataRow dr1;
            sd1.Fill(dt1);
            dr1 = dt1.Rows[0];
            zipc = Convert.ToString(dr1[0]);
            city = Convert.ToString(dr1[1]);
        }

        public int LoginA(string log,string pass)
        {
            string select = "select count(*) from AdminData where LoginId =" + int.Parse(log);

            SqlCommand cmd = new SqlCommand(select, con);
            int num = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (num > 0)
            {
                string passa = "select Password from AdminData where LoginId =" + int.Parse(log);
                //SqlCommand cmd1 = new SqlCommand(pass, conn);
                SqlDataAdapter ad = new SqlDataAdapter(passa, con);
                DataSet pawa = new DataSet();
                ad.Fill(pawa);

                int flag = 0;
                foreach (DataRow item in pawa.Tables[0].Rows)
                {
                    if (item[0].ToString() == pass.ToString())
                    {
                        flag = 1;
                        
                    }
                }
                return flag;
            }
            else
            {
                return 0;
            }


        }
        public int LoginU(string log, string pass)
        {
            string select = "select count(*) from UserData where LoginId =" + int.Parse(log);

            SqlCommand cmd = new SqlCommand(select, con);
            int num = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (num > 0)
            {
                string passa = "select Password from UserData where LoginId =" + int.Parse(log);
                //SqlCommand cmd1 = new SqlCommand(pass, conn);
                SqlDataAdapter ad = new SqlDataAdapter(passa, con);
                DataSet pawa = new DataSet();
                ad.Fill(pawa);

                int flag = 0;
                foreach (DataRow item in pawa.Tables[0].Rows)
                {
                    if (item[0].ToString() == pass.ToString())
                    {
                        flag = 1;

                    }
                }
                return flag;
            }
            else
            {
                return 0;
            }
        }

        public void conclose()
        {
            con.Close();
        }
        public void cook(string sl,string pl)
        {
             string select = "select count(*) from UserData where LoginId =" + int.Parse(sl);

            SqlCommand cmd = new SqlCommand(select, con);
            int num = Convert.ToInt32(cmd.ExecuteScalar().ToString());

            if (num > 0)
            {
                string pass = "select Password from UserData where LoginId =" + int.Parse(sl);

                SqlDataAdapter ad = new SqlDataAdapter(pass, con);
                DataSet paw = new DataSet();
                ad.Fill(paw);

 
                foreach (DataRow item in paw.Tables[0].Rows)
                {
                    if (item[0].ToString() == pl.ToString())
                    {
                        //System.Web.HttpContext.Current.Response.Write(" successful");
                        //Response.Write(" successful");
                      
                        HttpCookie ck = new HttpCookie("login1");
                        ck.Value = sl;
                        ck.Expires = DateTime.Now.AddMinutes(1);
                        System.Web.HttpContext.Current.Response.Cookies.Add(ck);
                        System.Web.HttpContext.Current.Response.Redirect("UserDataTableM.aspx");
                    }

                }

            }
           
        }
            
          
            

        
    }
}