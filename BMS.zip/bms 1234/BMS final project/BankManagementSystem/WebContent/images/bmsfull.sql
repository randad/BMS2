-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bms
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `branch_name` varchar(20) DEFAULT NULL,
  `ifsc_code` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `name` varchar(20) DEFAULT NULL,
  `guardian_type` varchar(20) DEFAULT NULL,
  `guardian_name` varchar(20) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `citizenship` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `country` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `marital_status` varchar(20) DEFAULT NULL,
  `contact_no` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `reg_date` date DEFAULT NULL,
  `acc_type` varchar(20) DEFAULT NULL,
  `branch_name` varchar(20) DEFAULT NULL,
  `citizen_status` varchar(20) DEFAULT NULL,
  `initial_deposit_amount` double DEFAULT NULL,
  `id_proof_type` varchar(10) DEFAULT NULL,
  `id_document_no` int(11) DEFAULT NULL,
  `ref_account_holder_name` varchar(20) DEFAULT NULL,
  `ref_account_holder_no` int(11) DEFAULT NULL,
  `ref_account_holder_address` varchar(20) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL,
  KEY `uid` (`uid`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `login` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `educational_details`
--

DROP TABLE IF EXISTS `educational_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `educational_details` (
  `uid` varchar(20) DEFAULT NULL,
  `course_fee` double DEFAULT NULL,
  `course` varchar(20) DEFAULT NULL,
  `father_name` varchar(20) DEFAULT NULL,
  `father_occupation` varchar(20) DEFAULT NULL,
  `father_tot_exp` int(11) DEFAULT NULL,
  `father_exp_with_company` int(11) DEFAULT NULL,
  `ration_card_no` int(11) DEFAULT NULL,
  `annual_income` double DEFAULT NULL,
  KEY `uid` (`uid`),
  CONSTRAINT `educational_details_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `login` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `educational_details`
--

LOCK TABLES `educational_details` WRITE;
/*!40000 ALTER TABLE `educational_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `educational_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_type` varchar(10) DEFAULT NULL,
  `loan_amount` double DEFAULT NULL,
  `apply_date` date DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `rate_of_intrest` double DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL,
  KEY `uid` (`uid`),
  CONSTRAINT `loan_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `login` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `uid` varchar(20) NOT NULL,
  `password` varchar(10) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_housing_details`
--

DROP TABLE IF EXISTS `personal_housing_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_housing_details` (
  `annual_income` double DEFAULT NULL,
  `company_name` varchar(20) DEFAULT NULL,
  `designation` varchar(20) DEFAULT NULL,
  `uid` varchar(20) DEFAULT NULL,
  `total_exp` int(11) DEFAULT NULL,
  `exp_with_company` int(11) DEFAULT NULL,
  KEY `uid` (`uid`),
  CONSTRAINT `personal_housing_details_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `login` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_housing_details`
--

LOCK TABLES `personal_housing_details` WRITE;
/*!40000 ALTER TABLE `personal_housing_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_housing_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `uid` varchar(20) DEFAULT NULL,
  `transaction_id` varchar(20) DEFAULT NULL,
  `transaction_type` varchar(20) DEFAULT NULL,
  `source_account_no` int(11) DEFAULT NULL,
  `destination_acc_no` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` double DEFAULT NULL,
  KEY `uid` (`uid`),
  CONSTRAINT `transaction_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `login` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-19 16:20:30
