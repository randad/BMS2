package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Transaction;
import service.TransactionBO;

@WebServlet("/TransactionController")
public class TransactionController extends HttpServlet {
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter pw = response.getWriter();
			Transaction t = new Transaction();
			System.out.println(request.getParameter("accountname"));
			t.setAcc_number(request.getParameter("accountno"));
			t.setAcc_name(request.getParameter("accountname"));
			t.setAcc_type(request.getParameter("accounttype"));
			//t.setTransaction_id(Integer.parseInt(request.getParameter("transaction_id")));
			t.setTransaction_type(request.getParameter("transactiontype"));
			
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
			String date = request.getParameter("transactiondate");
			try {
				t.setDate_of_transaction(sdf.parse(date));
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			t.setTransaction_amount(Float.parseFloat(request.getParameter("amount")));
			System.out.println(t);
			try{
			if(TransactionBO.registertransaction(t)){
				
				System.out.println("SUCCESS");
RequestDispatcher dispatcher = null;
				
				dispatcher = request.getRequestDispatcher("/view/main.jsp");
			
			dispatcher.forward(request, response);
			}
			else{
				System.out.println("Failed");
			}
			}catch(Exception e){
				System.out.println(e);
			}
			
			
	}
	}

