package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Customer;
import service.LoginBO;
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	
	protected void doPost(final HttpServletRequest request,
			final HttpServletResponse response) throws ServletException,
			IOException {
		Customer cust = new Customer();
		String username = request.getParameter("uname");// Username entered
		
		// by the user in the login page
		String passWord = request.getParameter("psw");// Password entered
		// by the user in the login page
	//	cust.setCustId(userid);
		cust.setPassword(passWord);
		cust.setUsername(username);
		
		 HttpSession session = request.getSession(true);
		 
	        session.setAttribute("userName", username);
	        System.out.println(session.getAttribute("userName"));
		 LoginBO logic = new LoginBO();// Creates an Object of LoginBO
		try {
			if(logic.validateUser(cust)){// Calls the validateUser method of the
			
		//	session.setAttribute("CustomerID", cust.getCustId());
			System.out.println("SUCCESS");
			
	       
			RequestDispatcher dispatcher = null;
				
				dispatcher = request.getRequestDispatcher("/view/main.jsp");
			
			dispatcher.forward(request, response); }
			else{
				RequestDispatcher dispatcher = null;
				System.out.println("FAILED");
				dispatcher = request
				.getRequestDispatcher("/view/error.html");
				dispatcher.include(request, response);
			}
			
		} 
		 catch (Exception e) {
				// TODO Auto-generated catch block
				System.out.println(e);
			}

	}

}


