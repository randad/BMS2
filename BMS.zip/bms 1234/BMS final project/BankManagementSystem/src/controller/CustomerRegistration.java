package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CustomerDAO;
import model.Customer;



@WebServlet("/CustomerRegistration")
public class CustomerRegistration extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		 System.out.println("in servlet");
		Customer  c= new Customer();
		//c.setCustId("custId");
		c.setCustomer_name(request.getParameter("name"));
		c.setUsername(request.getParameter("username"));
	
		String psw=request.getParameter("psw");
		String psw_re=request.getParameter("psw_re");
		
		
			c.setPassword(request.getParameter("psw"));
		
		c.setGaurdian_type(request.getParameter("Guardian Type"));
		c.setGaurdian_name(request.getParameter("Guardian Name"));
		c.setAddress(request.getParameter("address"));
		c.setCitizenship(request.getParameter("citizenship"));
		c.setState(request.getParameter("state"));
		c.setCountry_id(request.getParameter("country"));
		c.setEmail_address(request.getParameter("email"));
		c.setGender(request.getParameter("gender"));
		c.setMarital_status(request.getParameter("maritalstatus"));
		c.setContact_no(Integer.parseInt(request.getParameter("contact")));
		
	String date=request.getParameter("dateofbirth");
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		try {
			c.setDate_of_birth(sdf.parse(date));
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	//	c.setRegistrationDate(request.getParameter("registrationdate"));
	//	String date1=request.getParameter("registrationDate");
//		try
//		{
//			//Date d=sdf.parse(date);
//		//	String strDate=sdf.format(d);
//					
//		  //   c.setDateofBirth(strDate);
//		//c.setRegistrationDate(sdf.parse(date1));
//		}
//		catch(Exception e)
//		{
//			System.out.println("edc:"+e);
//		}
//		
		
		c.setAccount_type(request.getParameter("accounttype"));
		c.setBranch_name(request.getParameter("branchname"));
		c.setCitizen_status(request.getParameter("citizen")); 
		c.setInitial_deposit_amount( Integer.parseInt(request.getParameter("initialamount")));
		c.setIdentification_proof_type(request.getParameter("identificationproof"));
		c.setIdentification_document_no(request.getParameter("documentno"));
		c.setReference_account_holder_name(request.getParameter("documentname"));
		c.setReference_account_holder_acc_no(Integer.parseInt(request.getParameter("documentaccno")));
		c.setReference_account_holder_address(request.getParameter("documentadd"));
	
	try{
		//if(CustomerBO.registerCustomer(c)){
		//boolean value=CustomerDAO.registerCustomer(c);
		
		if(CustomerDAO.register(c)){
			RequestDispatcher dispatch=request.getRequestDispatcher("/view/successRegiter.html");
			dispatch.forward(request, response);
		}
		else{
			RequestDispatcher dispatch=request.getRequestDispatcher("/view/error.html");
			dispatch.include(request, response);
		}
		}catch(Exception e){
			System.out.println("exception e"+e);
		}
	}

}