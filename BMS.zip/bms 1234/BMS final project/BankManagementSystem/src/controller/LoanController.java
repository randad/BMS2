package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Loan;


@WebServlet("/LoanController")
public class LoanController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		   
	     String loanType=(String)request.getParameter("LoanType");  
	     
	     String cust_id=null;
		Loan  loan= new Loan();
		//loan.setLoan_id(request.getParameter("Loan_id"));
	//	loan.setCustId(custId);
		loan.setLoan_Type(loanType);
	 
	 String coursefee=request.getParameter("coursefee");
		String course=request.getParameter("course");
		String fathername=request.getParameter("fathername");
		String fexperience=request.getParameter("fexperience");
		String fcurrentexperience=request.getParameter("fcurrentexperience");
		String experience=request.getParameter("experience");
		String currentexperience=request.getParameter("currentexperience");
		String rationcard=request.getParameter("rationcard");
		String annualincome=request.getParameter("annualincome");
		String company=request.getParameter("company");
		String Designation=request.getParameter("Designation");
		int loanamount=Integer.parseInt(request.getParameter("loanamount"));
		
		
		System.out.println(annualincome);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String date = request.getParameter("loanapplydate");
		String date1 = request.getParameter("loanissuedate");
		Date loanapplyDate=null;
		Date loanIssueDate=null;
		
		try {
			loanapplyDate=sdf.parse(date);
			loanIssueDate=sdf.parse(date1);
		} 
		catch (ParseException e) {
			System.out.println("edc:"+e);
			}
		double rateofinterest=Double.parseDouble(request.getParameter("rateofinterest"));
		String duration=request.getParameter("duration");
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/bmsdb";
			Connection con=	  DriverManager.getConnection(url,"root","root");
			
			
		
			int resultTest=0,resultTest1=0,resultTest2=0;
			
			String s="select loan_id from loan_details;";
	           
	           Statement st=con.createStatement();
	           ResultSet rst=st.executeQuery(s);
	           while(rst.next()){};
	           rst.previous();
	           String s1=rst.getString(1);
	           String s2=s1.substring(2);
	           int i=Integer.parseInt(s2);
	           i=i+1;
	         DecimalFormat myFormatter = new DecimalFormat("000");
	         String output = myFormatter.format(i);
	           String loanId=s.substring(0,2)+output;
	            System.out.println("got loan id");
	            
	            
	            

				String s21="select loan_id from loan_details;";
		           
		           Statement st2=con.createStatement();
		           ResultSet rst2=st2.executeQuery(s21);
		           while(rst2.next()){};
		           rst2.previous();
		           String s12=rst2.getString(1);
		           String s22=s12.substring(2);
		           int i2=Integer.parseInt(s22);
		           i2=i2+1;
		         DecimalFormat myFormatter2 = new DecimalFormat("000");
		         String output2 = myFormatter.format(i2);
		           String loanId2=s12.substring(0,2)+output2;
		            System.out.println("got loan id2");
		            
		            
		            
		            
	           
	           
			String loanSQL = "insert into loan_details(loan_id,customer_id,loan_type,loan_amount,loan_apply_date,loan_issue_date,rate_of_interest,loan_duration) values(?,?,?,?,?,?,?,?)";
			PreparedStatement pstat=con.prepareStatement(loanSQL);
			SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
			
		   pstat.setString(1,loanId);
		   HttpSession session=request.getSession(true); 
		   String name=(String) session.getAttribute("userName");
		   System.out.println(name);
		   String c="select customer_id from customer_details where user_name='"+name+"'";
		   Statement cs=con.createStatement();
		   ResultSet crs=cs.executeQuery(c);
		   crs.next();
		   cust_id=crs.getString(1);
		   System.out.println("got cust id");
		pstat.setString(2, cust_id);
			pstat.setString(3, loanType);
			pstat.setDouble(4,loanamount);
			pstat.setString(5,  sdf1.format(loanapplyDate));
			pstat.setString(6,  sdf1.format(loanIssueDate));
			pstat.setDouble(7, rateofinterest);
			pstat.setString(8,duration);
			
			resultTest=    pstat.executeUpdate(); 
			System.out.println("inserted in to loan details");
			
			if(loanType.equalsIgnoreCase("personal"))
			{
			String ploanSQL = "insert into personal_loan(loan_id,annual_income,company_name,designation,total_exp,exp_with_current_company,customer_id)values(?,?,?,?,?,?,?)";
					
			
			PreparedStatement pstat1=con.prepareStatement(ploanSQL);
			
			pstat1.setString(1, loanId2);
			pstat1.setDouble(2,Double.parseDouble(annualincome));
			pstat1.setString(3, company);
			pstat1.setString(4, Designation);
			pstat1.setString(5, experience);
			pstat1.setString(6, currentexperience);
			pstat1.setString(7,cust_id);
			
			resultTest1=    pstat1.executeUpdate(); 
			
			if(resultTest1>=1){
				RequestDispatcher dispatch=request.getRequestDispatcher("/view/successLoan.jsp");
				dispatch.forward(request, response);
			}
			else{
				RequestDispatcher dispatch=request.getRequestDispatcher("/view/error.html");
				dispatch.forward(request, response);
			}
			
			}
			else if(loanType.equalsIgnoreCase("education")){
			String eloanSQL = "insert into education_loan(customer_id,loan_id,course_fee,course,father_name,father_total_experience,father_exp,ration_card_no,annual_income) values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstat2=con.prepareStatement(eloanSQL);
			pstat2.setString(1,cust_id);
			pstat2.setString(2, loanId);
			pstat2.setDouble(3,Integer.parseInt( coursefee));
			pstat2.setString(4, course);
			pstat2.setString(5,fathername);
			pstat2.setString(6,fexperience);
			pstat2.setString(7,fcurrentexperience);
			pstat2.setString(8,rationcard);
			pstat2.setDouble(9,Double.parseDouble(annualincome));
			resultTest2=    pstat2.executeUpdate();
			System.out.println("inserted in to education loan details");
			if(resultTest2>=1){
				RequestDispatcher dispatch=request.getRequestDispatcher("/view/successLoan.jsp");
				dispatch.forward(request, response);
			}
			else{
				RequestDispatcher dispatch=request.getRequestDispatcher("/view/error.html");
				dispatch.forward(request, response);
			}
			}
			
		
			
		}
		catch(Exception e)
		 {
			System.out.println("exception e"+e);
		}
	}
	
	public static int getCustId() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost/bms";
		Connection con=	  DriverManager.getConnection(url,"root","root");
		
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select count(distinct cust_id) from customer_details");
		
		int n=0;
		while(rs.next())
		{
			n=rs.getInt(1);
		}
		++n;
		return n;
		
	}
	}



