package model;


import java.io.Serializable;
import java.util.Date;

public class Customer implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String customer_name;
	private String username;
	private String password;
	private String gaurdian_type;
	private String gaurdian_name;
	private String address;
	private String citizenship;
	private String state;
	private String country;
	private String email_address;
	private String gender;
	private String marital_status;
	private int contact_no;
	private Date date_of_birth;
	//private Date registration_date;
	private String account_type;
	private String branch_name;
	private String citizen_status;
	private int initial_deposit_amount;
	private String identification_proof_type;
	private String identification_document_no;
	private String reference_account_holder_name;
	private int reference_account_holder_acc_no;
	private String reference_account_holder_address;
	private String customer_id;
	private String country_id;
	private String account_number;
	private int zipcode;
	private String city;
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGaurdian_type() {
		return gaurdian_type;
	}
	public void setGaurdian_type(String gaurdian_type) {
		this.gaurdian_type = gaurdian_type;
	}
	public String getGaurdian_name() {
		return gaurdian_name;
	}
	public void setGaurdian_name(String gaurdian_name) {
		this.gaurdian_name = gaurdian_name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCitizenship() {
		return citizenship;
	}
	public void setCitizenship(String citizenship) {
		this.citizenship = citizenship;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getEmail_address() {
		return email_address;
	}
	public void setEmail_address(String email_address) {
		this.email_address = email_address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMarital_status() {
		return marital_status;
	}
	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}
	public int getContact_no() {
		return contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	public Date getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
//	public Date getRegistration_date() {
//		return registration_date;
//	}
//	public void setRegistration_date(Date registration_date) {
//		this.registration_date = registration_date;
//	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	public String getCitizen_status() {
		return citizen_status;
	}
	public void setCitizen_status(String citizen_status) {
		this.citizen_status = citizen_status;
	}
	public int getInitial_deposit_amount() {
		return initial_deposit_amount;
	}
	public void setInitial_deposit_amount(int initial_deposit_amount) {
		this.initial_deposit_amount = initial_deposit_amount;
	}
	public String getIdentification_proof_type() {
		return identification_proof_type;
	}
	public void setIdentification_proof_type(String identification_proof_type) {
		this.identification_proof_type = identification_proof_type;
	}
	public String getIdentification_document_no() {
		return identification_document_no;
	}
	public void setIdentification_document_no(String identification_document_no) {
		this.identification_document_no = identification_document_no;
	}
	public String getReference_account_holder_name() {
		return reference_account_holder_name;
	}
	public void setReference_account_holder_name(
			String reference_account_holder_name) {
		this.reference_account_holder_name = reference_account_holder_name;
	}
	public int getReference_account_holder_acc_no() {
		return reference_account_holder_acc_no;
	}
	public void setReference_account_holder_acc_no(
			int reference_account_holder_acc_no) {
		this.reference_account_holder_acc_no = reference_account_holder_acc_no;
	}
	public String getReference_account_holder_address() {
		return reference_account_holder_address;
	}
	public void setReference_account_holder_address(
			String reference_account_holder_address) {
		this.reference_account_holder_address = reference_account_holder_address;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCountry_id() {
		return country_id;
	}
	public void setCountry_id(String country_id) {
		this.country_id = country_id;
	}
	public String getAccount_number() {
		return account_number;
	}
	public void setAccount_number(String string) {
		this.account_number = string;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Customer [customer_name=" + customer_name + ", username="
				+ username + ", password=" + password + ", gaurdian_type="
				+ gaurdian_type + ", gaurdian_name=" + gaurdian_name
				+ ", address=" + address + ", citizenship=" + citizenship
				+ ", state=" + state + ", country=" + country
				+ ", email_address=" + email_address + ", gender=" + gender
				+ ", marital_status=" + marital_status + ", contact_no="
				+ contact_no + ", date_of_birth=" + date_of_birth
				+ ", account_type=" + account_type + ", branch_name="
				+ branch_name + ", citizen_status=" + citizen_status
				+ ", initial_deposit_amount=" + initial_deposit_amount
				+ ", identification_proof_type=" + identification_proof_type
				+ ", identification_document_no=" + identification_document_no
				+ ", reference_account_holder_name="
				+ reference_account_holder_name
				+ ", reference_account_holder_acc_no="
				+ reference_account_holder_acc_no
				+ ", reference_account_holder_address="
				+ reference_account_holder_address + ", customer_id="
				+ customer_id + ", country_id=" + country_id
				+ ", account_number=" +  ", zipcode=" + zipcode
				+ ", city=" + city + "]";
	}
	
	
	
	
}


