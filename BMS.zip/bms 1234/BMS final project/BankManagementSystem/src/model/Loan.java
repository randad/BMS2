package model;

import java.util.Date;

public class Loan {
	private int Loan_id;
	private String Loan_Type;
//	private String CustId;
	private int Loan_Amount;
	private Date Loan_Apply_Date;
	private Date Loan_Issue_Date;
	private double Rate_Of_Interest;
	private String Duration_Of_The_Loan;
	private double Course_Fee;
	private String Course;
	private String Father_Name;
	//private String Occupation;
	private String Father_Total_Exp;
	private String Father_Exp_with_current_Company;
	private String Ration_Card_No;
	private double Annual_Income;
	private String Company_Name;
	private String Designation;
	private String Total_Exp;
	private String Exp_with_current_Company;
	

	public int getLoan_id() {
		return Loan_id;
	}


	public void setLoan_id(int loan_id) {
		Loan_id = loan_id;
	}


	public String getLoan_Type() {
		return Loan_Type;
	}


	public void setLoan_Type(String loan_Type) {
		Loan_Type = loan_Type;
	}


	public int getLoan_Amount() {
		return Loan_Amount;
	}


	public void setLoan_Amount(int loan_Amount) {
		Loan_Amount = loan_Amount;
	}


	public Date getLoan_Apply_Date() {
		return Loan_Apply_Date;
	}


	public void setLoan_Apply_Date(Date loan_Apply_Date) {
		Loan_Apply_Date = loan_Apply_Date;
	}


	public Date getLoan_Issue_Date() {
		return Loan_Issue_Date;
	}


	public void setLoan_Issue_Date(Date loan_Issue_Date) {
		Loan_Issue_Date = loan_Issue_Date;
	}


	public double getRate_Of_Interest() {
		return Rate_Of_Interest;
	}


	public void setRate_Of_Interest(double rate_Of_Interest) {
		Rate_Of_Interest = rate_Of_Interest;
	}


	public String getDuration_Of_The_Loan() {
		return Duration_Of_The_Loan;
	}


	public void setDuration_Of_The_Loan(String duration_Of_The_Loan) {
		Duration_Of_The_Loan = duration_Of_The_Loan;
	}


	public double getCourse_Fee() {
		return Course_Fee;
	}


	public void setCourse_Fee(double course_Fee) {
		Course_Fee = course_Fee;
	}


	public String getCourse() {
		return Course;
	}


	public void setCourse(String course) {
		Course = course;
	}


	public String getFather_Name() {
		return Father_Name;
	}


	public void setFather_Name(String father_Name) {
		Father_Name = father_Name;
	}


	public String getFather_Total_Exp() {
		return Father_Total_Exp;
	}


	public void setFather_Total_Exp(String father_Total_Exp) {
		Father_Total_Exp = father_Total_Exp;
	}


	public String getFather_Exp_with_current_Company() {
		return Father_Exp_with_current_Company;
	}


	public void setFather_Exp_with_current_Company(String father_Exp_with_current_Company) {
		Father_Exp_with_current_Company = father_Exp_with_current_Company;
	}


	public String getRation_Card_No() {
		return Ration_Card_No;
	}


	public void setRation_Card_No(String ration_Card_No) {
		Ration_Card_No = ration_Card_No;
	}


	public double getAnnual_Income() {
		return Annual_Income;
	}


	public void setAnnual_Income(double annual_Income) {
		Annual_Income = annual_Income;
	}


	public String getCompany_Name() {
		return Company_Name;
	}


	public void setCompany_Name(String company_Name) {
		Company_Name = company_Name;
	}


	public String getDesignation() {
		return Designation;
	}


	public void setDesignation(String designation) {
		Designation = designation;
	}


	public String getTotal_Exp() {
		return Total_Exp;
	}


	public void setTotal_Exp(String total_Exp) {
		Total_Exp = total_Exp;
	}


	public String getExp_with_current_Company() {
		return Exp_with_current_Company;
	}


	public void setExp_with_current_Company(String exp_with_current_Company) {
		Exp_with_current_Company = exp_with_current_Company;
	}


	@Override
	public String toString() {
		return "loandetails [Loan_Type=" + Loan_Type + ", Loan_Amount="
				+ Loan_Amount + ", Loan_Apply_Date=" + Loan_Apply_Date
				+ ", Loan_Issue_Date=" + Loan_Issue_Date
				+ ", Rate_Of_Interest=" + Rate_Of_Interest
				+ ", Duration_Of_The_Loan=" + Duration_Of_The_Loan
				+ ", Course_Fee=" + Course_Fee + ", Course=" + Course
				+ ", Father_Name=" + Father_Name 
				+ ", Father_Total_Exp=" + Father_Total_Exp
				+ ", Father_Exp_with_current_Company="
				+ Father_Exp_with_current_Company + ", Ration_Card_No="
				+ Ration_Card_No + ", Annual_Income=" + Annual_Income
				+ ", Company_Name=" + Company_Name + ", Designation="
				+ Designation + ",Total_Exp="+Total_Exp+",Exp_with_current_Company="+Exp_with_current_Company+"]";
	}
	
	
}
