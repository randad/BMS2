package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;



public class DatabaseConnector {
	private static Connection databaseConnection = null;
	static String url="jdbc:mysql://localhost:3306/bmsdb";
	static String user="root";
	static String password="root";
    public static Connection getDatabaseConnection() {
        try {
        	 try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			databaseConnection = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return databaseConnection;
    }

    public void close() throws SQLException {
        databaseConnection.close();
    }
}
