package model;

import java.util.Date;

public class Transaction {
	private String acc_number;
	private String acc_name;
	private String acc_type;
	private int transaction_id;
	private String transaction_type;
	private Date date_of_transaction;
	public Date getDate_of_transaction() {
		return date_of_transaction;
	}
	public void setDate_of_transaction(Date date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	private float transaction_amount;
	public String getAcc_number() {
		return acc_number;
	}
	public void setAcc_number(String acc_number) {
		this.acc_number = acc_number;
	}
	public String getAcc_name() {
		return acc_name;
	}
	public void setAcc_name(String acc_name) {
		this.acc_name = acc_name;
	}
	public String getAcc_type() {
		return acc_type;
	}
	public void setAcc_type(String acc_type) {
		this.acc_type = acc_type;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
	public float getTransaction_amount() {
		return transaction_amount;
	}
	public void setTransaction_amount(float transaction_amount) {
		this.transaction_amount = transaction_amount;
	}
	@Override
	public String toString() {
		return "transaction_details [acc_number=" + acc_number + ", acc_name="
				+ acc_name + ", acc_type=" + acc_type + ", transaction_id="
				+ transaction_id + ", transaction_type=" + transaction_type
				+ ", transaction_amount=" + transaction_amount + "]";
	}

}
