package dao;

import java.sql.*;

import model.Customer;

public class UserDao {
	public static boolean getUserDetails(Customer cust) throws Exception
	{

ResultSet result = null;
PreparedStatement statement = null;


Class.forName("com.mysql.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/bmsdb";

Connection con=	  DriverManager.getConnection(url,"root","root");
	String password;

	
	String loginSql = "select password  from customer_details where user_name =?";
	
			
	statement = con.prepareStatement(loginSql);
	
	statement.setString(1, cust.getUsername());
	 result = statement.executeQuery();
	 
	while( result.next()){
	 
	 password = result.getString(1);
System.out.println("password from user dao:"+password);


	if (password == null) {
		return false;
	} else if (password != null && cust.getPassword().equals(password)) {
		return true;
	} 
	}
 
return false;
}

}
