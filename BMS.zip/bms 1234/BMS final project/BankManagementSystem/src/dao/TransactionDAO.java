package dao;

import java.sql.*;

import model.Transaction;

public class TransactionDAO {
	public static boolean registertransaction(Transaction t) {
		
		boolean result =  false;
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost/bmsdb";
			
		Connection con=	  DriverManager .getConnection(url,"root","root");
		String transactionSQL = "insert into transaction_details(account_number,"
				+ "date_of_transaction,transaction_type,transaction_amount)values(?,?,?,?)";
		PreparedStatement pstat=con.prepareStatement(transactionSQL);
		pstat.setString(1, t.getAcc_number());
		//pstat.setString(3, t.getAcc_type());
//		pstat.setDouble(3, t.getTransaction_amount());
//		//pstat.setInt(4, t.getTransaction_id());
	pstat.setString(3, t.getTransaction_type());
		pstat.setDate(2, new java.sql.Date(t.getDate_of_transaction().getTime()));
		pstat.setFloat(4, t.getTransaction_amount());
		int resultTest= pstat.executeUpdate();
		
		if(resultTest>=1)
		{String s=null;
			if((t.getTransaction_type()).equals("deposit")){
			s="update account_details set available_balance=available_balance+? where account_number=?";}
			else{
				s="update account_details set available_balance=available_balance-? where account_number=?";}
			
			
			PreparedStatement p=con.prepareStatement(s);
			p.setFloat(1,t.getTransaction_amount());
			p.setString(2,t.getAcc_number());
			p.executeUpdate();
			result=true;
			
		}
		
	}
	catch(Exception e)
	 {
		System.out.println("exception e"+e);
	}
	System.out.println("in dao id:"+result);
	return result;
	}

	

}
