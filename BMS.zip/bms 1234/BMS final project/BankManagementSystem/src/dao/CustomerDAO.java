package dao;

import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.sql.*;

import com.sun.org.apache.xerces.internal.util.DOMUtil;

import model.*;

public class CustomerDAO  {
	static java.util.Date d =(java.util.Date) new Date();
                public static Connection con;
                static int count=0;
                static int temp=0;
                public static int generateCustId() throws SQLException, ClassNotFoundException, IOException{
                                con=DatabaseConnector.getDatabaseConnection();
                                System.out.println("in generate");
                                                
                                String sql="select count(*) as Count_ro from customer_details";
                                PreparedStatement pstat=con.prepareStatement(sql);
                                ResultSet rs=    pstat.executeQuery();
                                rs.next();
                                count=rs.getInt("Count_ro")+1;
                                
                                                
                                
                                return count;
                }

                public static boolean register(Customer c) {

                                boolean result=false;
                                try{
                                                con=DatabaseConnector.getDatabaseConnection();
                                                
                                                System.out.println("in registere");
                                                
                                                String registerSQL= "insert into customer_details values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
            
           String s="select * from customer_details;";
           System.out.println("before creating stat");
           Statement st=con.createStatement();
           ResultSet rst=st.executeQuery(s);
           while(rst.next()){};
           rst.previous();
           String s1=rst.getString(1);
           String s2=s1.substring(2);
           int i=Integer.parseInt(s2);
           i=i+1;
         DecimalFormat myFormatter = new DecimalFormat("000");
         String output = myFormatter.format(i);
           String s3=s.substring(0,2)+output;
            c.setCustomer_id(s3);
            System.out.println("after getting customer id");
            System.out.println(s3);
            String s5="select account_number from account_details;";
           
            Statement st5=con.createStatement();
            ResultSet rst5=st5.executeQuery(s5);
            while(rst5.next()){};
            rst5.previous();
            int z=Integer.parseInt(rst5.getString(1));
            z=z+1;
            c.setAccount_number(Integer.toString(z));
            PreparedStatement pstat=
                               con.prepareStatement(registerSQL);
            pstat.setString(1, c.getCustomer_id());
            pstat.setString(2, c.getCustomer_name());
            pstat.setString(3,c.getUsername());
            pstat.setString(4,c.getPassword());
            pstat.setString(5,c.getGaurdian_type());
            pstat.setString(6,c.getGaurdian_name());
            pstat.setString(7,c.getAddress());
            pstat.setString(8,c.getCountry_id());
            pstat.setString(9,c.getEmail_address());
            pstat.setString(10,c.getGender());
            pstat.setString(11, c.getMarital_status());
            pstat.setInt(12, c.getContact_no());
            pstat.setDate(13,new java.sql.Date(c.getDate_of_birth().getTime()));
            pstat.setString(14,c.getBranch_name());
            pstat.setString(15,c.getCitizenship());
            pstat.setString(16,c.getIdentification_proof_type());
            pstat.setString(17,c.getIdentification_document_no());
            pstat.setString(18,c.getReference_account_holder_name());
            pstat.setLong(19,c.getReference_account_holder_acc_no());
            pstat.setString(20,c.getReference_account_holder_address());
            System.out.println("after setting data");
            int resultTest=pstat.executeUpdate();
            System.out.println("after putting data into cdetails");
            String accRegisterSQL="insert into account_details values (?,?,?,?,null,?,?)";

                                                PreparedStatement pstat2=
                                                                                con.prepareStatement(accRegisterSQL);
                                                pstat2.setString(2, c.getCustomer_id());
                                                pstat2.setString(1, c.getAccount_number());
                                                SimpleDateFormat sdf=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
                                              String d2=sdf.format(d);
                                                pstat2.setString(3,  d2);
                                                pstat2.setString(4, c.getAccount_type());
                                               
                                                pstat2.setLong(5, c.getInitial_deposit_amount());
                                                pstat2.setLong(6, c.getInitial_deposit_amount());
                                                
                                                int resultTest2=   pstat2.executeUpdate();
                                                System.out.println("after putting data into account d");
            if(resultTest>=1)
            {
              // if(resultTest>=1 && resultTest2>=1){
                                                                result=true;
                //                                }
                                                
                                }
                                }
                                catch(Exception e)
                                 {
                                                System.out.println("exception e"+e);
                                }
                                
                                return result;
                }
                
                
                ////verify login
                public String verifyLogin(Customer e){
            		PreparedStatement preparedStatement = null;
            		String status=null;
            		try {
            			con=DatabaseConnector.getDatabaseConnection();
            			//retrieve bean object properties
            			
            			String customer_id=e.getCustomer_id();
            			String password=e.getPassword();
            			//System.out.println(userName+" "+password);
            			preparedStatement=con.prepareStatement("select customer_id from customer_details where customer_id=? AND password=?");
            			preparedStatement.setString(1,customer_id);
            			preparedStatement.setString(2, password);
            			//System.out.println("before execution");
            			
            			ResultSet rs=preparedStatement.executeQuery();
            			while(rs.next()){
            					//System.out.println("while");
            				
            				status=rs.getString(1);
            			}
            			/*if(rs!=null){
            				rs.next();
            				
            				
            			}*/
            			//System.out.println(status);
            			
            			
            		} catch (SQLException e1) {
            			// TODO Auto-generated catch block
            			e1.printStackTrace();
            		}
            		return status;

            }
                
}
