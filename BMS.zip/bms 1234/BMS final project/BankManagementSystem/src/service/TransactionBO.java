package service;

import dao.TransactionDAO;
import model.Transaction;

public class TransactionBO {
	public static boolean registertransaction(Transaction t)
	{
		
		boolean result=false;
		
		   result= TransactionDAO.registertransaction(t);
		 
		return result;
		
	}
}
