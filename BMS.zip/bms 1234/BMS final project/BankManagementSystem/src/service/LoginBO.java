package service;

import dao.UserDao;
import model.Customer;

public class LoginBO {
	public boolean validateUser(Customer cust) throws Exception
	{
		boolean result=UserDao.getUserDetails(cust);
		
		return result;
	}

}
