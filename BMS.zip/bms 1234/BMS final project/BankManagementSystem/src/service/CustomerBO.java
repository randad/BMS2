package service;

import dao.CustomerDAO;
import model.Customer;

public class CustomerBO {
	public static boolean registerCustomer(Customer cust) throws Exception
	{
		
	/*	
		String custIdPattern="R-";  

	String custId="";
	int count=CustomerDAO.generateCustId()+1;
	if(count<1000){
		custId="00"+count;
	}
	else if(count>9&& count<100)
		custId="0"+count;
	
	//custId=custIdPattern+custId;
		//cust.setCustId(custId);
		
		//cust.setAccountNumber(padLeftZeros(Integer.toString(count), 10));//padLeftZeros(Integer.toString(count), 10)
		boolean result=false;*/
		 System.out.println("in bo");
		boolean   result= CustomerDAO.register(cust);
		 
		return result;
		
	 
}
//	public static String padLeftZeros(String str, int n) {
//	    return String.format("%1$" + n + "s", str).replace(' ', '0');
//	  }

}
