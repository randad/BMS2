-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bmsdb
-- ------------------------------------------------------
-- Server version	5.7.15-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_details`
--

DROP TABLE IF EXISTS `account_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_details` (
  `account_number` varchar(16) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `acc_reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `account_type` varchar(50) NOT NULL,
  `acc_activation_date` date DEFAULT NULL,
  `opening_balance` decimal(10,2) NOT NULL,
  `available_balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`account_number`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `account_details_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_details` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_details`
--

LOCK TABLES `account_details` WRITE;
/*!40000 ALTER TABLE `account_details` DISABLE KEYS */;
INSERT INTO `account_details` VALUES ('0000000001','R-001','2018-03-29 07:13:43','savings',NULL,100000.00,115200.00),('000000002','se002','2018-06-22 06:20:37','savings',NULL,10000.00,10000.00),('3','se003','2018-07-22 06:37:14','savings',NULL,10000.00,21000.00);
/*!40000 ALTER TABLE `account_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `citizen_status`
--

DROP TABLE IF EXISTS `citizen_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `citizen_status` (
  `age` int(5) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`age`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `citizen_status`
--

LOCK TABLES `citizen_status` WRITE;
/*!40000 ALTER TABLE `citizen_status` DISABLE KEYS */;
INSERT INTO `citizen_status` VALUES (18,'Minor'),(60,'Senior');
/*!40000 ALTER TABLE `citizen_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_details`
--

DROP TABLE IF EXISTS `country_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country_details` (
  `id` varchar(3) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_details`
--

LOCK TABLES `country_details` WRITE;
/*!40000 ALTER TABLE `country_details` DISABLE KEYS */;
INSERT INTO `country_details` VALUES ('C01','India','TamilNadu'),('C02','India','Kerala'),('C03','India','Karnataka'),('C04','India','Andhra Pradesh'),('C05','UK','Scotland'),('C06','USA','New Jersey'),('C07','Italy','Rome');
/*!40000 ALTER TABLE `country_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_details`
--

DROP TABLE IF EXISTS `customer_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_details` (
  `customer_id` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `guardian_type` varchar(50) NOT NULL,
  `guardian_name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `country_id` varchar(3) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `martial_status` varchar(50) NOT NULL,
  `contact_number` varchar(50) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `branch_name` varchar(50) NOT NULL,
  `citzenship` varchar(50) NOT NULL,
  `id_prooftype` varchar(50) NOT NULL,
  `id_no` varchar(20) NOT NULL,
  `reference_acc_name` varchar(50) NOT NULL,
  `reference_acc_no` varchar(20) NOT NULL,
  `reference_acc_address` varchar(50) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_details`
--

LOCK TABLES `customer_details` WRITE;
/*!40000 ALTER TABLE `customer_details` DISABLE KEYS */;
INSERT INTO `customer_details` VALUES ('R-001','Sriram','sriram','1234','father','father','Hyderabad','ind','abcd@gmail.com','male','single','1234567890','1995-09-30','sbi-pune','IND','adharr','123456','goaj','12345','delhi'),('se002','Ajinkya','ajinkya','ajinkay','father','ajinkya','pune','ind','ajinkya@gmail.com','male','single','1234567890','1995-03-30','sbi-pune','IND','pan','12345678','abcd','1234','pune'),('se003','karan gupta','karan','karan','father','ajinkya','pune','ind','ajinkya@gmail.com','male','single','1234567890','1995-03-30','sbi-pune','IND','pan','12345678','abcd','1234','pune');
/*!40000 ALTER TABLE `customer_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education_loan`
--

DROP TABLE IF EXISTS `education_loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `education_loan` (
  `customer_id` varchar(20) NOT NULL,
  `loan_id` varchar(10) NOT NULL,
  `course_fee` decimal(10,2) NOT NULL,
  `course` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `father_total_experience` int(10) NOT NULL,
  `father_exp` int(10) NOT NULL,
  `ration_card_no` int(100) NOT NULL,
  `annual_income` decimal(10,2) NOT NULL,
  KEY `loan_id` (`loan_id`),
  CONSTRAINT `education_loan_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loan_details` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education_loan`
--

LOCK TABLES `education_loan` WRITE;
/*!40000 ALTER TABLE `education_loan` DISABLE KEYS */;
INSERT INTO `education_loan` VALUES ('se003','se002',2000.00,'abc','xyz',5,5,1244,123465.00),('se003','se003',2000.00,'abc','xyz',5,5,1244,123465.00),('se003','se004',20009.00,'abc','xyz',5,5,1244,123465.00);
/*!40000 ALTER TABLE `education_loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ifsc`
--

DROP TABLE IF EXISTS `ifsc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ifsc` (
  `branch_name` varchar(50) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ifsc`
--

LOCK TABLES `ifsc` WRITE;
/*!40000 ALTER TABLE `ifsc` DISABLE KEYS */;
INSERT INTO `ifsc` VALUES ('VALASARAVAKKAM','HDVL0012'),('TNAGAR','HDTN0013'),('TNAGAR','SBITN0123'),('SAIDAPET','SBISD0113'),('TNAGAR','ICITN0232'),('PERUNGUDI','ICIPG0242'),('TNAGAR','AXTN0342'),('NUMGAMBAKKAM','AXNU0356');
/*!40000 ALTER TABLE `ifsc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `initial_deposit`
--

DROP TABLE IF EXISTS `initial_deposit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `initial_deposit` (
  `account_type` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `initial_amt` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `initial_deposit`
--

LOCK TABLES `initial_deposit` WRITE;
/*!40000 ALTER TABLE `initial_deposit` DISABLE KEYS */;
INSERT INTO `initial_deposit` VALUES ('Saving','India',5000.00),('Saving','UK',14000.00),('Saving','US',15000.00),('Saving','Italy',13000.00),('Salary','India',0.00),('Salary','UK',0.00),('Salary','US',0.00),('Salary','Italy',0.00);
/*!40000 ALTER TABLE `initial_deposit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan_details`
--

DROP TABLE IF EXISTS `loan_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan_details` (
  `loan_id` varchar(10) NOT NULL,
  `customer_id` varchar(20) NOT NULL,
  `loan_type` varchar(50) NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `loan_apply_date` varchar(50) DEFAULT NULL,
  `loan_issue_date` varchar(50) NOT NULL,
  `rate_of_interest` decimal(10,2) NOT NULL,
  `loan_duration` int(10) NOT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `loan_details_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_details` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan_details`
--

LOCK TABLES `loan_details` WRITE;
/*!40000 ALTER TABLE `loan_details` DISABLE KEYS */;
INSERT INTO `loan_details` VALUES ('l-001','se003','education',10000.00,'2018-06-22','2018-06-22 12:51:52',8.00,8),('se002','se003','education',2000.00,'2018-12-12','2018-12-12',8.00,8),('se003','se003','education',2000.00,'2018-12-12','2018-12-12',8.00,8),('se004','se003','education',2000.00,'2018-12-12','2018-12-12',8.00,8),('se005','se003','personal',20003.00,'2018-12-12','2018-12-12',8.00,10),('se006','se003','personal',20003.00,'2018-12-12','2018-12-12',8.00,10),('se007','se003','personal',20003.00,'2018-12-12','2018-12-12',8.00,10),('se008','se003','personal',20003.00,'2018-12-12','2018-12-12',8.00,10),('se009','se003','personal',2000.00,'2018-12-12','2018-12-12',8.00,10),('se010','se003','personal',2000.00,'2018-12-12','2018-12-12',8.00,10);
/*!40000 ALTER TABLE `loan_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_loan`
--

DROP TABLE IF EXISTS `personal_loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_loan` (
  `loan_id` varchar(10) NOT NULL,
  `annual_income` decimal(10,2) NOT NULL,
  `company_name` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `total_exp` decimal(10,2) NOT NULL,
  `exp_with_current_company` int(10) NOT NULL,
  `customer_id` varchar(45) NOT NULL,
  KEY `loan_id` (`loan_id`),
  CONSTRAINT `personal_loan_ibfk_1` FOREIGN KEY (`loan_id`) REFERENCES `loan_details` (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_loan`
--

LOCK TABLES `personal_loan` WRITE;
/*!40000 ALTER TABLE `personal_loan` DISABLE KEYS */;
INSERT INTO `personal_loan` VALUES ('l-001',100000.00,'abc','xyz',5.00,5,'se000'),('se010',123465.00,'abc','xyz',9.00,9,'se003');
/*!40000 ALTER TABLE `personal_loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rate_of_interest`
--

DROP TABLE IF EXISTS `rate_of_interest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rate_of_interest` (
  `status` varchar(10) NOT NULL,
  `interest` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rate_of_interest`
--

LOCK TABLES `rate_of_interest` WRITE;
/*!40000 ALTER TABLE `rate_of_interest` DISABLE KEYS */;
INSERT INTO `rate_of_interest` VALUES ('Normal',10.00),('Senior',15.00);
/*!40000 ALTER TABLE `rate_of_interest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_details`
--

DROP TABLE IF EXISTS `transaction_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_details` (
  `transaction_id` int(10) NOT NULL AUTO_INCREMENT,
  `account_number` varchar(16) NOT NULL,
  `date_of_transaction` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `transaction_type` varchar(50) NOT NULL,
  `transaction_amount` decimal(10,2) NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `account_number` (`account_number`),
  CONSTRAINT `transaction_details_ibfk_1` FOREIGN KEY (`account_number`) REFERENCES `account_details` (`account_number`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_details`
--

LOCK TABLES `transaction_details` WRITE;
/*!40000 ALTER TABLE `transaction_details` DISABLE KEYS */;
INSERT INTO `transaction_details` VALUES (1,'3','2018-02-11 18:30:00','deposit',5000.00),(2,'3','2018-02-11 18:30:00','deposit',6000.00);
/*!40000 ALTER TABLE `transaction_details` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-22 15:55:02
