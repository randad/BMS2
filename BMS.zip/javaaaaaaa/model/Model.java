package model;
import java.util.Date;

public class Model {
	int login_id;
	String password;
	String first_name;
	String last_name;
	int age;
	String gender;
	int contact_no;
	String email;
	String address ;
	int zipcode;
	String city_id ;
	String flag ;
	int status;
	int rating;
	int day_due_past;
	String account_no;
	String comments;
	int transaction_id;
	int transaction_type;
	Date transaction_date;
	double amount_transferred;
	String transferred_to;
	String transferred_from;
	String transferred_branch;
	double amount_borrowed;
	double amount_repaid;
	String borrower_name;
	String accrual_status;
	long bank_number;
	public Model(int login_id, String password, String first_name, String last_name, int age, String gender,
			int contact_no, String email, String address, int zipcode, String city_id, String flag, int status,
			int rating, int day_due_past, String account_no, String comments, int transaction_id, int transaction_type,
			Date transaction_date, double amount_transferred, String transferred_to, String transferred_from,
			String transferred_branch, double amount_borrowed, double amount_repaid, String borrower_name,
			String accrual_status, long bank_number) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.first_name = first_name;
		this.last_name = last_name;
		this.age = age;
		this.gender = gender;
		this.contact_no = contact_no;
		this.email = email;
		this.address = address;
		this.zipcode = zipcode;
		this.city_id = city_id;
		this.flag = flag;
		this.status = status;
		this.rating = rating;
		this.day_due_past = day_due_past;
		this.account_no = account_no;
		this.comments = comments;
		this.transaction_id = transaction_id;
		this.transaction_type = transaction_type;
		this.transaction_date = transaction_date;
		this.amount_transferred = amount_transferred;
		this.transferred_to = transferred_to;
		this.transferred_from = transferred_from;
		this.transferred_branch = transferred_branch;
		this.amount_borrowed = amount_borrowed;
		this.amount_repaid = amount_repaid;
		this.borrower_name = borrower_name;
		this.accrual_status = accrual_status;
		this.bank_number = bank_number;
	}
	public Model(int login_id,int status, int rating, int day_due_past, String account_no, String comments, String borrower_name,
			String accrual_status, long bank_number) {
		super();
		this.login_id=login_id;
		this.status = status;
		this.rating = rating;
		this.day_due_past = day_due_past;
		this.account_no = account_no;
		this.comments = comments;
		this.borrower_name = borrower_name;
		this.accrual_status = accrual_status;
		this.bank_number = bank_number;
	}
	public Model() {
		super();
	}
	public int getLogin_id() {
		return login_id;
	}
	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getContact_no() {
		return contact_no;
	}
	public void setContact_no(int contact_no) {
		this.contact_no = contact_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public String getCity_id() {
		return city_id;
	}
	public void setCity_id(String city_id) {
		this.city_id = city_id;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getDay_due_past() {
		return day_due_past;
	}
	public void setDay_due_past(int day_due_past) {
		this.day_due_past = day_due_past;
	}
	public String getAccount_no() {
		return account_no;
	}
	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(int transaction_type) {
		this.transaction_type = transaction_type;
	}
	public Date getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(Date transaction_date) {
		this.transaction_date = transaction_date;
	}
	public double getAmount_transferred() {
		return amount_transferred;
	}
	public void setAmount_transferred(double amount_transferred) {
		this.amount_transferred = amount_transferred;
	}
	public String getTransferred_to() {
		return transferred_to;
	}
	public void setTransferred_to(String transferred_to) {
		this.transferred_to = transferred_to;
	}
	public String getTransferred_from() {
		return transferred_from;
	}
	public void setTransferred_from(String transferred_from) {
		this.transferred_from = transferred_from;
	}
	public String getTransferred_branch() {
		return transferred_branch;
	}
	public void setTransferred_branch(String transferred_branch) {
		this.transferred_branch = transferred_branch;
	}
	public double getAmount_borrowed() {
		return amount_borrowed;
	}
	public void setAmount_borrowed(double amount_borrowed) {
		this.amount_borrowed = amount_borrowed;
	}
	public double getAmount_repaid() {
		return amount_repaid;
	}
	public void setAmount_repaid(double amount_repaid) {
		this.amount_repaid = amount_repaid;
	}
	public String getBorrower_name() {
		return borrower_name;
	}
	public void setBorrower_name(String borrower_name) {
		this.borrower_name = borrower_name;
	}
	public String getAccrual_status() {
		return accrual_status;
	}
	public void setAccrual_status(String accrual_status) {
		this.accrual_status = accrual_status;
	}
	public long getBank_number() {
		return bank_number;
	}
	public void setBank_number(long bank_number) {
		this.bank_number = bank_number;
	}
	
	
	
}