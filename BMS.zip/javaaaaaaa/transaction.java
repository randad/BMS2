import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class transaction extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public transaction() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		 String s1=request.getParameter("userid");
	
	 String s3=request.getParameter("transaction_type");
	 String s4=request.getParameter("transaction_date");
	 String s5=request.getParameter("amount_transferred");
	 String s6=request.getParameter("transferred_to");
	 String s7=request.getParameter("transferred_from");
	 String s8=request.getParameter("transferred_branch");
	 String s9=request.getParameter("amount_borrowed");
	 String s10=request.getParameter("amount_repaid");
	 
	  
	 
	
	 try{
		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		 
		 SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		 java.util.Date d=sdf.parse(s4);
		 java.sql.Date d1=new java.sql.Date(d.getTime());
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
		 System.out.println("Succesful");
		 String q = "INSERT INTO transaction"
					+ "(login_id,transaction_id,transaction_type,transaction_date,amount_transferred,transferred_to,transferred_from,transferred_branch,amount_borrowed,amount_repaid) VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?)";
		 System.out.println("1");
			PreparedStatement preparedStatement = con.prepareStatement(q);
			
			preparedStatement.setInt(1, Integer.parseInt(s1));
			
			preparedStatement.setInt(2, 23);
			
			preparedStatement.setString(3, s3);
			
			preparedStatement.setDate(4, d1);
			
            preparedStatement.setInt(5, Integer.parseInt(s5));
            System.out.println("7");
			preparedStatement.setString(6, s6);
			System.out.println("8");
			preparedStatement.setString(7, s7);
			System.out.println("9");
			preparedStatement.setString(8, s8);
			System.out.println("10");
			preparedStatement.setInt(9, Integer.parseInt(s9));
			System.out.println("11");
			preparedStatement.setInt(10, Integer.parseInt(s10));
			System.out.println("12");
			
			
			
			// execute insert SQL stetement
		
		 int i=preparedStatement.executeUpdate();
		 if(i==1)
		 {
		 }
		 else
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("/signup.html");
			 rd.forward(request, response);
		 }
			 
	 }catch(Exception e)
	 {
		System.out.println(e);
	 }
	 out.flush();
	 out.flush();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}