import java.util.Date;

public class trans {
	int login_id;
	static int transaction_id=0;
	int transaction_type;
	Date transaction_date;
	double amount_transferred;
	String transferred_to;
	String transferred_from;
	String transferred_branch;
	double amount_borrowed;
	double amount_repaid;
	public trans( int login_id, int transaction_id, int transaction_type, Date transaction_date, double amount_transferred,
			String transferred_to, String transferred_from, String transferred_branch, double amount_borrowed,
			double amount_repaid) {
		super();
		this.login_id=login_id;
		this.transaction_id = transaction_id;
		this.transaction_type = transaction_type;
		this.transaction_date = transaction_date;
		this.amount_transferred = amount_transferred;
		this.transferred_to = transferred_to;
		this.transferred_from = transferred_from;
		this.transferred_branch = transferred_branch;
		this.amount_borrowed = amount_borrowed;
		this.amount_repaid = amount_repaid;
	}
	public trans() {
		super();
		transaction_id++;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(int transaction_type) {
		this.transaction_type = transaction_type;
	}
	public Date getTransaction_date() {
		return transaction_date;
	}
	public void setTransaction_date(Date transaction_date) {
		this.transaction_date = transaction_date;
	}
	public double getAmount_transferred() {
		return amount_transferred;
	}
	public void setAmount_transferred(double amount_transferred) {
		this.amount_transferred = amount_transferred;
	}
	public String getTransferred_to() {
		return transferred_to;
	}
	public void setTransferred_to(String transferred_to) {
		this.transferred_to = transferred_to;
	}
	public String getTransferred_from() {
		return transferred_from;
	}
	public void setTransferred_from(String transferred_from) {
		this.transferred_from = transferred_from;
	}
	public String getTransferred_branch() {
		return transferred_branch;
	}
	public void setTransferred_branch(String transferred_branch) {
		this.transferred_branch = transferred_branch;
	}
	public double getAmount_borrowed() {
		return amount_borrowed;
	}
	public void setAmount_borrowed(double amount_borrowed) {
		this.amount_borrowed = amount_borrowed;
	}
	public double getAmount_repaid() {
		return amount_repaid;
	}
	public void setAmount_repaid(double amount_repaid) {
		this.amount_repaid = amount_repaid;
	}
	public int getLogin_id() {
		return login_id;
	}
	public void setLogin_id(int login_id) {
		this.login_id = login_id;
	}
	
	
}