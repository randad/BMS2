import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class aipadmin extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public aipadmin() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	 String s1=request.getParameter("pass");
	 String s2=request.getParameter("fname");
	 String s3=request.getParameter("lname");
	 String s4=request.getParameter("age");
	 String s5=request.getParameter("gender");
	 String s6=request.getParameter("contactno");
	 String s7=request.getParameter("email");
	 String s8=request.getParameter("address");
	 String s9=request.getParameter("zipcode");
	 String s10=request.getParameter("location");
	
	 try{
		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
		 
		 String q = "INSERT INTO registration"
					+ "(password,first_name,last_name,age,gender,contact_no,email,address,zipcode,city_name,flag) VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = con.prepareStatement(q);
			preparedStatement.setString(1, s1);
			
			preparedStatement.setString(2, s2);
			preparedStatement.setString(3, s3);
			
			preparedStatement.setInt(4, Integer.parseInt(s4));
			
            preparedStatement.setString(5, s5);
            
			preparedStatement.setInt(6,Integer.parseInt(s6));
			
			preparedStatement.setString(7, s7);
			
			preparedStatement.setString(8, s8);
			preparedStatement.setInt(9, Integer.parseInt(s9));
			
			preparedStatement.setString(10, s10);
			preparedStatement.setString(11, "admin");
			// execute insert SQL stetement
		
		 int i=preparedStatement.executeUpdate();
		 if(i==1)
		 {
			 
			 RequestDispatcher rd=request.getRequestDispatcher("/aipadmin.html");
			 rd.forward(request, response);
		 }
		 else
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("/signup.html");
			 rd.forward(request, response);
		 }
			 
	 }catch(Exception e)
	 {
		System.out.println(e);
	 }
	 out.flush();
	 out.flush();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}