import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class insertdetails extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor of the object.
	 */
	public insertdetails() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out
				.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">");
		out.println("<HTML>");
		out.println("  <HEAD><TITLE>A Servlet</TITLE></HEAD>");
		out.println("  <BODY>");
		out.print("    This is ");
		out.print(this.getClass());
		out.println(", using the GET method");
		out.println("  </BODY>");
		out.println("</HTML>");
		out.flush();
		out.close();
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
	 String s1=request.getParameter("fname");
	 String s2=request.getParameter("lname");
	 String s3=request.getParameter("age");
	 String s4=request.getParameter("gender");
	 String s5=request.getParameter("contactno");
	 String s6=request.getParameter("email");
	 String s7=request.getParameter("address");
	 String s8=request.getParameter("zipcode");
	 String s9=request.getParameter("location");
	 String s10=request.getParameter("status");
	 String s11=request.getParameter("rating");
	 String s12=request.getParameter("dpd");
	 String s13=request.getParameter("accno");
	 String s14=request.getParameter("comments");
	 String s15=request.getParameter("borrowername");
	 String s16=request.getParameter("accrualstatus");
	 String s17=request.getParameter("bank_no");
	  
	 
	
	 try{
		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
		 System.out.println("Succesful");
		 String q = "INSERT INTO registration"
					+ "(first_name,last_name,age,gender,contact_no,email,address,zipcode,city_name,status,rating,day_due_past,account_no,comments,borrower_name,accrual_status,bank_number,flag) VALUES"
					+ "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement preparedStatement = con.prepareStatement(q);
			preparedStatement.setString(1, s1);
			preparedStatement.setString(2, s2);
			preparedStatement.setInt(3, Integer.parseInt(s3));
			preparedStatement.setString(4, s4);
            preparedStatement.setInt(5, Integer.parseInt(s5));
			preparedStatement.setString(6, s6);
			preparedStatement.setString(7, s7);
			preparedStatement.setInt(8, Integer.parseInt(s8));
			preparedStatement.setString(9, s9);
			preparedStatement.setInt(10, Integer.parseInt(s10));
			preparedStatement.setInt(11, Integer.parseInt(s11));
			preparedStatement.setInt(12, Integer.parseInt(s12));
			preparedStatement.setString(13, s13);
			preparedStatement.setString(14, s14);
			preparedStatement.setString(15, s15);
			preparedStatement.setString(16, s16);
			preparedStatement.setInt(17, Integer.parseInt(s17));
			preparedStatement.setString(18, "user");
			
			
			// execute insert SQL stetement
		
		 int i=preparedStatement.executeUpdate();
		 if(i==1)
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("/userinfo.jsp");
			 rd.forward(request, response);
		 }
		 else
		 {
			 RequestDispatcher rd=request.getRequestDispatcher("/signup.html");
			 rd.forward(request, response);
		 }
			 
	 }catch(Exception e)
	 {
		System.out.println(e);
	 }
	 out.flush();
	 out.flush();
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}