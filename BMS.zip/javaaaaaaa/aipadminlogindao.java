import java.net.ResponseCache;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import model.*;
import javax.servlet.RequestDispatcher;



public class aipadminlogindao
{
	
	public static String queryRole(Model r1)
	{
		boolean i= false;
		String str=null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
			 java.sql.Statement st=con.createStatement();
			 String q="select * from registration where login_id='"+r1.getLogin_id()+"' and password = '"+r1.getPassword()+"'";
	          ResultSet rs=st.executeQuery(q);
	          while(rs.next())
	          {
	          str=rs.getString(4);
	          }
		}
		catch(Exception e)
		{
			
		}
		return str;
	}
	public static boolean checkLogin(Model r1)
	{
		boolean i= false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
			 java.sql.Statement st=con.createStatement();
			 String q="select * from registration where login_id='"+r1.getLogin_id()+"' and password = '"+r1.getPassword()+"'";
	          ResultSet rs=st.executeQuery(q);
	          if(rs.next())
	          { 
	        	  i=true;
	          }
	          else
	          {
	        	  System.out.println("Wrong Password");
               i=false;
	          }
	           /*rs.next();
	           Integer user;
	           String pass;
	           user =Integer.parseInt(rs.getString("login_id"));
	           pass =rs.getString("password");
	           { if(Integer.valueOf(Registration.getLogin_id()).compareTo(user)==0)
	                 if(r1.getPassword().compareTo(pass)==0)
	                     System.out.println("login Success");
	                 else
	                     System.out.println("Wrong Password");

	           }*/
		}catch(Exception e)
		{
			System.out.println(e); 
		}
		return i;
	}
}
