
 
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

 
/**
 * ControllerServlet.java
 * This servlet acts as a page controller for the application, handling all
 * requests from the user.
 * @author www.codejava.net
 */
public class controller extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private admindao q2;
 
   
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	response.setContentType("text/html");
    	PrintWriter pw=response.getWriter();
        String action = request.getServletPath();
        
        if(request.getParameter("autodefaulter")!=null)
        {
        	admindao ad=new admindao();
        	try
        	{
        	ArrayList<Model> list=(ArrayList<Model>) ad.listautodefaulters();
        	
        	request.setAttribute("lis", list);
        	//HttpSession session=request.getSession();
        	//session.setAttribute("lis", list);
        	RequestDispatcher rs=request.getRequestDispatcher("./autodefaulters.jsp");
        	rs.forward(request, response);
        	//response.sendRedirect("./autodefaulters.jsp");
        	}
        	catch(Exception e)
        	{
        		
        	}
        }
        if(request.getParameter("login")!=null)
        {
        	admindao ad=new admindao();
        	try
        	{
        	ArrayList<Model> list=(ArrayList<Model>) ad.listautodefaulters();
        	
        	request.setAttribute("lis", list);
        	//HttpSession session=request.getSession();
        	//session.setAttribute("lis", list);
        	RequestDispatcher rs=request.getRequestDispatcher("./transactiondisplay.jsp");
        	rs.forward(request, response);
        	//response.sendRedirect("./autodefaulters.jsp");
        	}
        	catch(Exception e)
        	{
        		
        	}
        }
        if(request.getParameter("manualdefaulter")!=null)
        {
        	admindao ad=new admindao();
        	try
        	{
        	ArrayList<Model> list=(ArrayList<Model>) ad.listmanualdefaulters();
        	request.setAttribute("lis", list);
        	//HttpSession session=request.getSession();
        	//session.setAttribute("lis", list);
        	RequestDispatcher rs=request.getRequestDispatcher("./manualdefaulters.jsp");
        	rs.forward(request, response);
        	//response.sendRedirect("./autodefaulters.jsp");
        	}
        	catch(Exception e)
        	{
        		
        	}
        }
 
       /* try {
            switch (action) {
           
            case "auto":
           //     listautodefaulter(request, response);
                break;
            case "manual":
               // listmanualdefaulter(request, response);
                break;
            case "/edit":
               //showEditForm(request, response);
                break;
            default:
              //  listautodefaulter(request, response);
                break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }*/
    }
 
   /* private void listautodefaulter(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Model> listBook = q2.listautodefaulters();
        request.setAttribute("listBook", listBook);
        RequestDispatcher dispatcher = request.getRequestDispatcher("autodefaulters.jsp");
        dispatcher.forward(request, response);
    }
    private void listmanualdefaulter(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Model> listBook1 = q2.listmanualdefaulters();
        request.setAttribute("listBook1", listBook1);
        RequestDispatcher dispatcher = request.getRequestDispatcher("manualdefaulters.jsp");
        dispatcher.forward(request, response);
    }*/
   
 
  /*  private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
       // Book existingBook = bookDAO.getBook(id);
        RequestDispatcher dispatcher = request.getRequestDispatcher("BookForm.jsp");
        request.setAttribute("book", existingBook);
        dispatcher.forward(request, response);
 
    }
 
   
    private void updateBook(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        float price = Float.parseFloat(request.getParameter("price"));
 
       // Book book = new Book(id, title, author, price);
       // bookDAO.updateBook(book);
       // response.sendRedirect("list");
    }*/
 
   
}