import java.sql.SQLException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.*;

import javax.servlet.RequestDispatcher;
public class admindao {
	 public  ArrayList<Model> listautodefaulters() throws SQLException {
	        ArrayList<Model> listBook = new ArrayList<Model>();
	        try{
	    		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    		 Class.forName("com.mysql.jdbc.Driver");
	    		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
	    		 String sql = "SELECT status,borrower_name,rating,accrual_status,bank_number,account_no,day_due_past,comments,login_id FROM registration where rating >8 and accrual_status=5";
	             
	    	      
	    	         
	    	        Connection jdbcConnection = null;
					Statement statement = con.createStatement();
	    	        ResultSet resultSet = statement.executeQuery(sql);
	    	         
	    	        while (resultSet.next()) {
	    	           
	    	            int s1 = resultSet.getInt(1);
	    	            String s2 = resultSet.getString(2);
	    	            int s3 = resultSet.getInt(3);
	    	            String s4 = resultSet.getString(4);
	    	           long s5 = resultSet.getLong(5);
	    	           String s6 = resultSet.getString(6);
	    	            int s7 = resultSet.getInt(7);
	    	            String s8 = resultSet.getString(8);
	    	           int s9=resultSet.getInt(9);
	    	             
	    	            Model q1 = new Model(s9,s1,s3,s7,s6,s8,s2,s4,s5);
	    	            listBook.add(q1);
	    	        }
	    	         
	    	        resultSet.close();
	    	        statement.close();
	    	         
	    	       
	    	         
	    	        
	    			 
	    	 }catch(Exception e)
	    	 {
	    		System.out.println(e);
	    	 }
			return listBook;
	    	 
	    	}
	
		 public  ArrayList<Model> listtransactiondetails() throws SQLException {
		        ArrayList<Model> listBook = new ArrayList<Model>();
		        try{
		    		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
		    		 Class.forName("com.mysql.jdbc.Driver");
		    		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
		    		 String sql = "SELECT transaction_type,transaction_date,amount_transferred,transferred_to,transferred_from,transferred_branch,amount_borrowed,amount_repaid FROM transaction where login_id=? ";
		             
		    	      
		    	         
		    	        Connection jdbcConnection = null;
						Statement statement = con.createStatement();
		    	        ResultSet resultSet = statement.executeQuery(sql);
		    	         
		    	        while (resultSet.next()) {
		    	           
		    	            int s1 = resultSet.getInt(1);
		    	            String s2 = resultSet.getString(2);
		    	            int s3 = resultSet.getInt(3);
		    	            String s4 = resultSet.getString(4);
		    	           long s5 = resultSet.getLong(5);
		    	           String s6 = resultSet.getString(6);
		    	            int s7 = resultSet.getInt(7);
		    	            String s8 = resultSet.getString(8);
		    	           int s9=resultSet.getInt(9);
		    	             
		    	            Model q1 = new Model(s9,s1,s3,s7,s6,s8,s2,s4,s5);
		    	            listBook.add(q1);
		    	        }
		    	         
		    	        resultSet.close();
		    	        statement.close();
		    	         
		    	       
		    	         
		    	        
		    			 
		    	 }catch(Exception e)
		    	 {
		    		System.out.println(e);
		    	 }
				return listBook;
		    	 
		    	}
	 public  List<Model> listmanualdefaulters() throws SQLException {
	        List<Model> listBook1 = new ArrayList<>();
	        try{
	    		// DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	    		 Class.forName("com.mysql.jdbc.Driver");
	    		 Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aip2","root","root");
	    		 String sql = "SELECT status,borrower_name,rating,accrual_status,bank_number,account_no,day_due_past,comments,login_id FROM registration where rating =9 and accrual_status =5";
	             
	    	      
	    	         
	    	        Connection jdbcConnection = null;
					Statement statement = con.createStatement();
	    	        ResultSet resultSet = statement.executeQuery(sql);
	    	         
	    	        while (resultSet.next()) {
	    	           
	    	            int s1 = resultSet.getInt("status");
	    	            String s2 = resultSet.getString("borrower_name");
	    	            int s3 = resultSet.getInt("rating");
	    	            String s4 = resultSet.getString("accrual_status");
	    	            long s5 = resultSet.getLong("bank_number");
	    	           String s6 = resultSet.getString("account_no");
	    	            int s7 = resultSet.getInt("day_due_past");
	    	            String s8 = resultSet.getString("comments");
	    	           int s9=resultSet.getInt(9);
	    	             
	    	            Model q1 = new Model(s9,s1,s3,s7,s6,s8,s2,s4,s5);
	    	            listBook1.add(q1);
	    	        }
	    	         
	    	        resultSet.close();
	    	        statement.close();
	    	         
	    	       
	    	         
	    	        
	    			 
	    	 }catch(Exception e)
	    	 {
	    		System.out.println(e);
	    	 }
			return listBook1;
	    	 
	    	}
}
